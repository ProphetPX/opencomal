/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "pdcpars.y"

#define YYDEBUG 1

/*
 * OpenComal -- a free Comal implementation
 *
 * This file is part of the OpenComal package.
 * (c) Copyright 1992-2002 Jos Visser <josv@osp.nl>
 *
 * The OpenComal package is covered by the GNU General Public
 * License. See doc/LICENSE for more information.
 */


/* The OpenComal parser */

#define PDCPARS

#include "pdcglob.h"
#include "pdcparss.h"
#include "pdcmisc.h"
#include "pdcid.h"
#include "pdcprog.h"

#include <string.h>

#define yyunion(x,y)	( (*(x)) = (*(y)) )

PUBLIC struct comal_line c_line;

PRIVATE void p_error(char *msg);

extern int yylex();


#line 107 "pdcpars.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "pdcpars.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_andSYM = 3,                     /* andSYM  */
  YYSYMBOL_andthenSYM = 4,                 /* andthenSYM  */
  YYSYMBOL_appendSYM = 5,                  /* appendSYM  */
  YYSYMBOL_autoSYM = 6,                    /* autoSYM  */
  YYSYMBOL_becomesSYM = 7,                 /* becomesSYM  */
  YYSYMBOL_becplusSYM = 8,                 /* becplusSYM  */
  YYSYMBOL_becminusSYM = 9,                /* becminusSYM  */
  YYSYMBOL_caseSYM = 10,                   /* caseSYM  */
  YYSYMBOL_chdirSYM = 11,                  /* chdirSYM  */
  YYSYMBOL_closedSYM = 12,                 /* closedSYM  */
  YYSYMBOL_closeSYM = 13,                  /* closeSYM  */
  YYSYMBOL_colonSYM = 14,                  /* colonSYM  */
  YYSYMBOL_commaSYM = 15,                  /* commaSYM  */
  YYSYMBOL_contSYM = 16,                   /* contSYM  */
  YYSYMBOL_cursorSYM = 17,                 /* cursorSYM  */
  YYSYMBOL_dataSYM = 18,                   /* dataSYM  */
  YYSYMBOL_delSYM = 19,                    /* delSYM  */
  YYSYMBOL_dimSYM = 20,                    /* dimSYM  */
  YYSYMBOL_dirSYM = 21,                    /* dirSYM  */
  YYSYMBOL_divideSYM = 22,                 /* divideSYM  */
  YYSYMBOL_divSYM = 23,                    /* divSYM  */
  YYSYMBOL_doSYM = 24,                     /* doSYM  */
  YYSYMBOL_downtoSYM = 25,                 /* downtoSYM  */
  YYSYMBOL_dynamicSYM = 26,                /* dynamicSYM  */
  YYSYMBOL_editSYM = 27,                   /* editSYM  */
  YYSYMBOL_elifSYM = 28,                   /* elifSYM  */
  YYSYMBOL_elseSYM = 29,                   /* elseSYM  */
  YYSYMBOL_endcaseSYM = 30,                /* endcaseSYM  */
  YYSYMBOL_endforSYM = 31,                 /* endforSYM  */
  YYSYMBOL_endfuncSYM = 32,                /* endfuncSYM  */
  YYSYMBOL_endifSYM = 33,                  /* endifSYM  */
  YYSYMBOL_endloopSYM = 34,                /* endloopSYM  */
  YYSYMBOL_endprocSYM = 35,                /* endprocSYM  */
  YYSYMBOL_endSYM = 36,                    /* endSYM  */
  YYSYMBOL_endtrapSYM = 37,                /* endtrapSYM  */
  YYSYMBOL_endwhileSYM = 38,               /* endwhileSYM  */
  YYSYMBOL_envSYM = 39,                    /* envSYM  */
  YYSYMBOL_enterSYM = 40,                  /* enterSYM  */
  YYSYMBOL_eolnSYM = 41,                   /* eolnSYM  */
  YYSYMBOL_eorSYM = 42,                    /* eorSYM  */
  YYSYMBOL_eqlSYM = 43,                    /* eqlSYM  */
  YYSYMBOL_escSYM = 44,                    /* escSYM  */
  YYSYMBOL_execSYM = 45,                   /* execSYM  */
  YYSYMBOL_exitSYM = 46,                   /* exitSYM  */
  YYSYMBOL_externalSYM = 47,               /* externalSYM  */
  YYSYMBOL_fileSYM = 48,                   /* fileSYM  */
  YYSYMBOL_forSYM = 49,                    /* forSYM  */
  YYSYMBOL_funcSYM = 50,                   /* funcSYM  */
  YYSYMBOL_geqSYM = 51,                    /* geqSYM  */
  YYSYMBOL_gtrSYM = 52,                    /* gtrSYM  */
  YYSYMBOL_handlerSYM = 53,                /* handlerSYM  */
  YYSYMBOL_ifSYM = 54,                     /* ifSYM  */
  YYSYMBOL_importSYM = 55,                 /* importSYM  */
  YYSYMBOL_inputSYM = 56,                  /* inputSYM  */
  YYSYMBOL_inSYM = 57,                     /* inSYM  */
  YYSYMBOL_leqSYM = 58,                    /* leqSYM  */
  YYSYMBOL_listSYM = 59,                   /* listSYM  */
  YYSYMBOL_localSYM = 60,                  /* localSYM  */
  YYSYMBOL_loadSYM = 61,                   /* loadSYM  */
  YYSYMBOL_loopSYM = 62,                   /* loopSYM  */
  YYSYMBOL_lparenSYM = 63,                 /* lparenSYM  */
  YYSYMBOL_lssSYM = 64,                    /* lssSYM  */
  YYSYMBOL_minusSYM = 65,                  /* minusSYM  */
  YYSYMBOL_mkdirSYM = 66,                  /* mkdirSYM  */
  YYSYMBOL_modSYM = 67,                    /* modSYM  */
  YYSYMBOL_nameSYM = 68,                   /* nameSYM  */
  YYSYMBOL_neqSYM = 69,                    /* neqSYM  */
  YYSYMBOL_newSYM = 70,                    /* newSYM  */
  YYSYMBOL_nullSYM = 71,                   /* nullSYM  */
  YYSYMBOL_ofSYM = 72,                     /* ofSYM  */
  YYSYMBOL_openSYM = 73,                   /* openSYM  */
  YYSYMBOL_orSYM = 74,                     /* orSYM  */
  YYSYMBOL_orthenSYM = 75,                 /* orthenSYM  */
  YYSYMBOL_osSYM = 76,                     /* osSYM  */
  YYSYMBOL_otherwiseSYM = 77,              /* otherwiseSYM  */
  YYSYMBOL_pageSYM = 78,                   /* pageSYM  */
  YYSYMBOL_plusSYM = 79,                   /* plusSYM  */
  YYSYMBOL_powerSYM = 80,                  /* powerSYM  */
  YYSYMBOL_printSYM = 81,                  /* printSYM  */
  YYSYMBOL_procSYM = 82,                   /* procSYM  */
  YYSYMBOL_quitSYM = 83,                   /* quitSYM  */
  YYSYMBOL_randomSYM = 84,                 /* randomSYM  */
  YYSYMBOL_readSYM = 85,                   /* readSYM  */
  YYSYMBOL_read_onlySYM = 86,              /* read_onlySYM  */
  YYSYMBOL_refSYM = 87,                    /* refSYM  */
  YYSYMBOL_renumberSYM = 88,               /* renumberSYM  */
  YYSYMBOL_repeatSYM = 89,                 /* repeatSYM  */
  YYSYMBOL_restoreSYM = 90,                /* restoreSYM  */
  YYSYMBOL_retrySYM = 91,                  /* retrySYM  */
  YYSYMBOL_returnSYM = 92,                 /* returnSYM  */
  YYSYMBOL_rmdirSYM = 93,                  /* rmdirSYM  */
  YYSYMBOL_rndSYM = 94,                    /* rndSYM  */
  YYSYMBOL_rparenSYM = 95,                 /* rparenSYM  */
  YYSYMBOL_runSYM = 96,                    /* runSYM  */
  YYSYMBOL_saveSYM = 97,                   /* saveSYM  */
  YYSYMBOL_scanSYM = 98,                   /* scanSYM  */
  YYSYMBOL_select_inputSYM = 99,           /* select_inputSYM  */
  YYSYMBOL_select_outputSYM = 100,         /* select_outputSYM  */
  YYSYMBOL_semicolonSYM = 101,             /* semicolonSYM  */
  YYSYMBOL_staticSYM = 102,                /* staticSYM  */
  YYSYMBOL_stepSYM = 103,                  /* stepSYM  */
  YYSYMBOL_stopSYM = 104,                  /* stopSYM  */
  YYSYMBOL_sysSYM = 105,                   /* sysSYM  */
  YYSYMBOL_syssSYM = 106,                  /* syssSYM  */
  YYSYMBOL_thenSYM = 107,                  /* thenSYM  */
  YYSYMBOL_timesSYM = 108,                 /* timesSYM  */
  YYSYMBOL_toSYM = 109,                    /* toSYM  */
  YYSYMBOL_traceSYM = 110,                 /* traceSYM  */
  YYSYMBOL_trapSYM = 111,                  /* trapSYM  */
  YYSYMBOL_unitSYM = 112,                  /* unitSYM  */
  YYSYMBOL_untilSYM = 113,                 /* untilSYM  */
  YYSYMBOL_usingSYM = 114,                 /* usingSYM  */
  YYSYMBOL_whenSYM = 115,                  /* whenSYM  */
  YYSYMBOL_whileSYM = 116,                 /* whileSYM  */
  YYSYMBOL_writeSYM = 117,                 /* writeSYM  */
  YYSYMBOL_rnSYM = 118,                    /* rnSYM  */
  YYSYMBOL_rsSYM = 119,                    /* rsSYM  */
  YYSYMBOL_tnrnSYM = 120,                  /* tnrnSYM  */
  YYSYMBOL_tnrsSYM = 121,                  /* tnrsSYM  */
  YYSYMBOL_tsrnSYM = 122,                  /* tsrnSYM  */
  YYSYMBOL_tonrsSYM = 123,                 /* tonrsSYM  */
  YYSYMBOL_tsrsSYM = 124,                  /* tsrsSYM  */
  YYSYMBOL_floatnumSYM = 125,              /* floatnumSYM  */
  YYSYMBOL_idSYM = 126,                    /* idSYM  */
  YYSYMBOL_intidSYM = 127,                 /* intidSYM  */
  YYSYMBOL_stringidSYM = 128,              /* stringidSYM  */
  YYSYMBOL_intnumSYM = 129,                /* intnumSYM  */
  YYSYMBOL_remSYM = 130,                   /* remSYM  */
  YYSYMBOL_stringSYM = 131,                /* stringSYM  */
  YYSYMBOL_USIGN = 132,                    /* USIGN  */
  YYSYMBOL_YYACCEPT = 133,                 /* $accept  */
  YYSYMBOL_a_comal_line = 134,             /* a_comal_line  */
  YYSYMBOL_comal_line = 135,               /* comal_line  */
  YYSYMBOL_optrem = 136,                   /* optrem  */
  YYSYMBOL_command = 137,                  /* command  */
  YYSYMBOL_list_cmd = 138,                 /* list_cmd  */
  YYSYMBOL_line_range = 139,               /* line_range  */
  YYSYMBOL_renumlines = 140,               /* renumlines  */
  YYSYMBOL_autolines = 141,                /* autolines  */
  YYSYMBOL_program_line = 142,             /* program_line  */
  YYSYMBOL_complex_stat = 143,             /* complex_stat  */
  YYSYMBOL_simple_stat = 144,              /* simple_stat  */
  YYSYMBOL_complex_1word = 145,            /* complex_1word  */
  YYSYMBOL_simple_1word = 146,             /* simple_1word  */
  YYSYMBOL_case_stat = 147,                /* case_stat  */
  YYSYMBOL_close_stat = 148,               /* close_stat  */
  YYSYMBOL_cursor_stat = 149,              /* cursor_stat  */
  YYSYMBOL_chdir_stat = 150,               /* chdir_stat  */
  YYSYMBOL_rmdir_stat = 151,               /* rmdir_stat  */
  YYSYMBOL_mkdir_stat = 152,               /* mkdir_stat  */
  YYSYMBOL_data_stat = 153,                /* data_stat  */
  YYSYMBOL_del_stat = 154,                 /* del_stat  */
  YYSYMBOL_dir_stat = 155,                 /* dir_stat  */
  YYSYMBOL_unit_stat = 156,                /* unit_stat  */
  YYSYMBOL_local_stat = 157,               /* local_stat  */
  YYSYMBOL_local_list = 158,               /* local_list  */
  YYSYMBOL_local_item = 159,               /* local_item  */
  YYSYMBOL_dim_stat = 160,                 /* dim_stat  */
  YYSYMBOL_dim_list = 161,                 /* dim_list  */
  YYSYMBOL_dim_item = 162,                 /* dim_item  */
  YYSYMBOL_of = 163,                       /* of  */
  YYSYMBOL_opt_dim_ensions = 164,          /* opt_dim_ensions  */
  YYSYMBOL_dim_ensions = 165,              /* dim_ensions  */
  YYSYMBOL_dim_ension_list = 166,          /* dim_ension_list  */
  YYSYMBOL_dim_ension = 167,               /* dim_ension  */
  YYSYMBOL_elif_stat = 168,                /* elif_stat  */
  YYSYMBOL_exit_stat = 169,                /* exit_stat  */
  YYSYMBOL_ifwhen = 170,                   /* ifwhen  */
  YYSYMBOL_exec_stat = 171,                /* exec_stat  */
  YYSYMBOL_for_stat = 172,                 /* for_stat  */
  YYSYMBOL_todownto = 173,                 /* todownto  */
  YYSYMBOL_optstep = 174,                  /* optstep  */
  YYSYMBOL_func_stat = 175,                /* func_stat  */
  YYSYMBOL_if_stat = 176,                  /* if_stat  */
  YYSYMBOL_import_stat = 177,              /* import_stat  */
  YYSYMBOL_import_list = 178,              /* import_list  */
  YYSYMBOL_input_stat = 179,               /* input_stat  */
  YYSYMBOL_input_modifier = 180,           /* input_modifier  */
  YYSYMBOL_open_stat = 181,                /* open_stat  */
  YYSYMBOL_open_type = 182,                /* open_type  */
  YYSYMBOL_os_stat = 183,                  /* os_stat  */
  YYSYMBOL_print_stat = 184,               /* print_stat  */
  YYSYMBOL_printi = 185,                   /* printi  */
  YYSYMBOL_prnum_list = 186,               /* prnum_list  */
  YYSYMBOL_print_list = 187,               /* print_list  */
  YYSYMBOL_pr_sep = 188,                   /* pr_sep  */
  YYSYMBOL_optpr_sep = 189,                /* optpr_sep  */
  YYSYMBOL_proc_stat = 190,                /* proc_stat  */
  YYSYMBOL_read_stat = 191,                /* read_stat  */
  YYSYMBOL_restore_stat = 192,             /* restore_stat  */
  YYSYMBOL_return_stat = 193,              /* return_stat  */
  YYSYMBOL_run_stat = 194,                 /* run_stat  */
  YYSYMBOL_select_out_stat = 195,          /* select_out_stat  */
  YYSYMBOL_select_in_stat = 196,           /* select_in_stat  */
  YYSYMBOL_stop_stat = 197,                /* stop_stat  */
  YYSYMBOL_sys_stat = 198,                 /* sys_stat  */
  YYSYMBOL_until_stat = 199,               /* until_stat  */
  YYSYMBOL_trace_stat = 200,               /* trace_stat  */
  YYSYMBOL_trap_stat = 201,                /* trap_stat  */
  YYSYMBOL_plusorminus = 202,              /* plusorminus  */
  YYSYMBOL_when_stat = 203,                /* when_stat  */
  YYSYMBOL_when_list = 204,                /* when_list  */
  YYSYMBOL_when_numlist = 205,             /* when_numlist  */
  YYSYMBOL_when_numitem = 206,             /* when_numitem  */
  YYSYMBOL_when_strlist = 207,             /* when_strlist  */
  YYSYMBOL_when_stritem = 208,             /* when_stritem  */
  YYSYMBOL_relop = 209,                    /* relop  */
  YYSYMBOL_while_stat = 210,               /* while_stat  */
  YYSYMBOL_repeat_stat = 211,              /* repeat_stat  */
  YYSYMBOL_write_stat = 212,               /* write_stat  */
  YYSYMBOL_assign_stat = 213,              /* assign_stat  */
  YYSYMBOL_assign_list = 214,              /* assign_list  */
  YYSYMBOL_assign_item = 215,              /* assign_item  */
  YYSYMBOL_nassign = 216,                  /* nassign  */
  YYSYMBOL_sassign = 217,                  /* sassign  */
  YYSYMBOL_assign1 = 218,                  /* assign1  */
  YYSYMBOL_assign2 = 219,                  /* assign2  */
  YYSYMBOL_label_stat = 220,               /* label_stat  */
  YYSYMBOL_xid = 221,                      /* xid  */
  YYSYMBOL_exp = 222,                      /* exp  */
  YYSYMBOL_numexp = 223,                   /* numexp  */
  YYSYMBOL_numexp2 = 224,                  /* numexp2  */
  YYSYMBOL_stringexp = 225,                /* stringexp  */
  YYSYMBOL_stringexp2 = 226,               /* stringexp2  */
  YYSYMBOL_opt_stringexp = 227,            /* opt_stringexp  */
  YYSYMBOL_string_factor = 228,            /* string_factor  */
  YYSYMBOL_opt_arg = 229,                  /* opt_arg  */
  YYSYMBOL_substr_spec = 230,              /* substr_spec  */
  YYSYMBOL_substr_spec2 = 231,             /* substr_spec2  */
  YYSYMBOL_optnumlvalue = 232,             /* optnumlvalue  */
  YYSYMBOL_optexp = 233,                   /* optexp  */
  YYSYMBOL_optid = 234,                    /* optid  */
  YYSYMBOL_optid2 = 235,                   /* optid2  */
  YYSYMBOL_optfile = 236,                  /* optfile  */
  YYSYMBOL_optfileS = 237,                 /* optfileS  */
  YYSYMBOL_lval_list = 238,                /* lval_list  */
  YYSYMBOL_lvalue = 239,                   /* lvalue  */
  YYSYMBOL_numlvalue = 240,                /* numlvalue  */
  YYSYMBOL_numlvalue2 = 241,               /* numlvalue2  */
  YYSYMBOL_strlvalue = 242,                /* strlvalue  */
  YYSYMBOL_strlvalue2 = 243,               /* strlvalue2  */
  YYSYMBOL_file_designator = 244,          /* file_designator  */
  YYSYMBOL_opt_external = 245,             /* opt_external  */
  YYSYMBOL_procfunc_head = 246,            /* procfunc_head  */
  YYSYMBOL_parmlist = 247,                 /* parmlist  */
  YYSYMBOL_parmitem = 248,                 /* parmitem  */
  YYSYMBOL_oneparm = 249,                  /* oneparm  */
  YYSYMBOL_id = 250,                       /* id  */
  YYSYMBOL_numid = 251,                    /* numid  */
  YYSYMBOL_opt_commalist = 252,            /* opt_commalist  */
  YYSYMBOL_exp_list = 253,                 /* exp_list  */
  YYSYMBOL_optsimple_stat = 254,           /* optsimple_stat  */
  YYSYMBOL_optfilename = 255,              /* optfilename  */
  YYSYMBOL_optof = 256,                    /* optof  */
  YYSYMBOL_optdo = 257,                    /* optdo  */
  YYSYMBOL_optthen = 258,                  /* optthen  */
  YYSYMBOL_optread_only = 259,             /* optread_only  */
  YYSYMBOL_optclosed = 260                 /* optclosed  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  237
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1474

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  133
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  128
/* YYNRULES -- Number of rules.  */
#define YYNRULES  364
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  568

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   387


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   235,   235,   240,   249,   254,   262,   267,   273,   275,
     281,   285,   286,   291,   296,   301,   306,   311,   315,   319,
     324,   328,   333,   338,   345,   352,   360,   367,   373,   382,
     385,   389,   393,   397,   403,   407,   411,   416,   421,   425,
     429,   435,   441,   442,   444,   449,   450,   451,   452,   453,
     454,   455,   456,   457,   458,   459,   460,   461,   462,   465,
     466,   467,   468,   469,   470,   471,   472,   473,   474,   475,
     476,   477,   478,   479,   480,   481,   482,   483,   484,   485,
     486,   487,   488,   489,   490,   491,   492,   497,   498,   501,
     505,   509,   513,   517,   521,   525,   529,   533,   537,   541,
     547,   552,   556,   562,   566,   570,   575,   579,   585,   592,
     597,   604,   612,   619,   626,   633,   640,   647,   654,   662,
     668,   673,   680,   684,   688,   692,   696,   703,   710,   715,
     722,   726,   730,   734,   740,   741,   744,   746,   751,   757,
     762,   769,   775,   781,   789,   796,   803,   804,   807,   814,
     826,   830,   836,   841,   846,   856,   864,   870,   878,   885,
     894,   902,   908,   915,   920,   929,   933,   937,   941,   949,
     956,   963,   970,   979,   990,   991,   994,   998,  1004,  1008,
    1014,  1018,  1024,  1026,  1031,  1041,  1049,  1056,  1063,  1070,
    1078,  1085,  1092,  1099,  1106,  1118,  1125,  1129,  1135,  1142,
    1143,  1146,  1151,  1154,  1158,  1164,  1169,  1172,  1176,  1180,
    1186,  1190,  1194,  1198,  1202,  1206,  1212,  1220,  1228,  1236,
    1243,  1248,  1254,  1258,  1264,  1265,  1268,  1269,  1275,  1279,
    1285,  1289,  1295,  1302,  1306,  1310,  1316,  1317,  1320,  1326,
    1330,  1334,  1338,  1342,  1346,  1350,  1354,  1358,  1362,  1366,
    1370,  1374,  1378,  1382,  1386,  1390,  1394,  1398,  1402,  1406,
    1410,  1414,  1418,  1422,  1426,  1430,  1434,  1438,  1442,  1443,
    1447,  1451,  1455,  1459,  1463,  1467,  1471,  1477,  1483,  1487,
    1488,  1494,  1496,  1501,  1502,  1506,  1510,  1514,  1518,  1522,
    1526,  1530,  1536,  1541,  1546,  1552,  1557,  1562,  1567,  1574,
    1576,  1581,  1583,  1588,  1590,  1595,  1597,  1602,  1609,  1614,
    1615,  1618,  1622,  1628,  1629,  1632,  1639,  1640,  1644,  1648,
    1654,  1661,  1665,  1669,  1673,  1677,  1683,  1688,  1695,  1703,
    1711,  1720,  1725,  1730,  1735,  1740,  1747,  1754,  1761,  1768,
    1775,  1784,  1789,  1796,  1797,  1800,  1801,  1804,  1805,  1808,
    1812,  1818,  1829,  1834,  1836,  1841,  1842,  1845,  1846,  1849,
    1850,  1853,  1858,  1863,  1868
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "andSYM", "andthenSYM",
  "appendSYM", "autoSYM", "becomesSYM", "becplusSYM", "becminusSYM",
  "caseSYM", "chdirSYM", "closedSYM", "closeSYM", "colonSYM", "commaSYM",
  "contSYM", "cursorSYM", "dataSYM", "delSYM", "dimSYM", "dirSYM",
  "divideSYM", "divSYM", "doSYM", "downtoSYM", "dynamicSYM", "editSYM",
  "elifSYM", "elseSYM", "endcaseSYM", "endforSYM", "endfuncSYM",
  "endifSYM", "endloopSYM", "endprocSYM", "endSYM", "endtrapSYM",
  "endwhileSYM", "envSYM", "enterSYM", "eolnSYM", "eorSYM", "eqlSYM",
  "escSYM", "execSYM", "exitSYM", "externalSYM", "fileSYM", "forSYM",
  "funcSYM", "geqSYM", "gtrSYM", "handlerSYM", "ifSYM", "importSYM",
  "inputSYM", "inSYM", "leqSYM", "listSYM", "localSYM", "loadSYM",
  "loopSYM", "lparenSYM", "lssSYM", "minusSYM", "mkdirSYM", "modSYM",
  "nameSYM", "neqSYM", "newSYM", "nullSYM", "ofSYM", "openSYM", "orSYM",
  "orthenSYM", "osSYM", "otherwiseSYM", "pageSYM", "plusSYM", "powerSYM",
  "printSYM", "procSYM", "quitSYM", "randomSYM", "readSYM", "read_onlySYM",
  "refSYM", "renumberSYM", "repeatSYM", "restoreSYM", "retrySYM",
  "returnSYM", "rmdirSYM", "rndSYM", "rparenSYM", "runSYM", "saveSYM",
  "scanSYM", "select_inputSYM", "select_outputSYM", "semicolonSYM",
  "staticSYM", "stepSYM", "stopSYM", "sysSYM", "syssSYM", "thenSYM",
  "timesSYM", "toSYM", "traceSYM", "trapSYM", "unitSYM", "untilSYM",
  "usingSYM", "whenSYM", "whileSYM", "writeSYM", "rnSYM", "rsSYM",
  "tnrnSYM", "tnrsSYM", "tsrnSYM", "tonrsSYM", "tsrsSYM", "floatnumSYM",
  "idSYM", "intidSYM", "stringidSYM", "intnumSYM", "remSYM", "stringSYM",
  "USIGN", "$accept", "a_comal_line", "comal_line", "optrem", "command",
  "list_cmd", "line_range", "renumlines", "autolines", "program_line",
  "complex_stat", "simple_stat", "complex_1word", "simple_1word",
  "case_stat", "close_stat", "cursor_stat", "chdir_stat", "rmdir_stat",
  "mkdir_stat", "data_stat", "del_stat", "dir_stat", "unit_stat",
  "local_stat", "local_list", "local_item", "dim_stat", "dim_list",
  "dim_item", "of", "opt_dim_ensions", "dim_ensions", "dim_ension_list",
  "dim_ension", "elif_stat", "exit_stat", "ifwhen", "exec_stat",
  "for_stat", "todownto", "optstep", "func_stat", "if_stat", "import_stat",
  "import_list", "input_stat", "input_modifier", "open_stat", "open_type",
  "os_stat", "print_stat", "printi", "prnum_list", "print_list", "pr_sep",
  "optpr_sep", "proc_stat", "read_stat", "restore_stat", "return_stat",
  "run_stat", "select_out_stat", "select_in_stat", "stop_stat", "sys_stat",
  "until_stat", "trace_stat", "trap_stat", "plusorminus", "when_stat",
  "when_list", "when_numlist", "when_numitem", "when_strlist",
  "when_stritem", "relop", "while_stat", "repeat_stat", "write_stat",
  "assign_stat", "assign_list", "assign_item", "nassign", "sassign",
  "assign1", "assign2", "label_stat", "xid", "exp", "numexp", "numexp2",
  "stringexp", "stringexp2", "opt_stringexp", "string_factor", "opt_arg",
  "substr_spec", "substr_spec2", "optnumlvalue", "optexp", "optid",
  "optid2", "optfile", "optfileS", "lval_list", "lvalue", "numlvalue",
  "numlvalue2", "strlvalue", "strlvalue2", "file_designator",
  "opt_external", "procfunc_head", "parmlist", "parmitem", "oneparm", "id",
  "numid", "opt_commalist", "exp_list", "optsimple_stat", "optfilename",
  "optof", "optdo", "optthen", "optread_only", "optclosed", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-451)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-110)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     635,    12,    17,   298,    32,  -451,   973,   343,   105,   298,
     -25,  -451,   -83,   -82,   -66,  -451,   163,   -23,   154,   184,
     -65,   298,  -451,  -451,    47,   298,  -451,  -451,  -451,    57,
      19,   -83,  -451,   973,   298,   298,   -65,  -451,   298,   298,
    -451,   973,   973,   973,    63,   298,    57,    50,    86,   110,
     757,  -451,   117,   143,  -451,  -451,  -451,  -451,  -451,  -451,
    -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,
    -451,  -451,  -451,  -451,  -451,  1343,  -451,  -451,  -451,  -451,
    -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,   106,  -451,
     -12,   220,  -451,   168,  -451,  -451,    87,   203,  -451,   298,
     171,  -451,   183,   198,   199,  -451,  -451,   -14,   209,  -451,
    -451,   973,   973,   973,   973,   211,   213,  -451,   215,   223,
    -451,  -451,  -451,   251,  1244,   456,  -451,   158,   227,  -451,
    -451,  -451,  -451,   115,   279,  -451,   232,  -451,  -451,  -451,
    -451,  -451,  -451,  -451,  -451,   281,  -451,    33,  -451,   973,
     299,   201,  -451,  -451,   301,   302,   116,   306,  -451,   232,
    -451,  -451,  -451,   973,  -451,   201,  -451,   185,   307,  -451,
    -451,  -451,  -451,  -451,   456,  -451,  -451,  -451,  -451,  -451,
    -451,  -451,  -451,   317,  -451,    95,  -451,   973,   973,   973,
       6,  -451,   973,   973,   298,   973,  -451,  -451,    74,   163,
    -451,  -451,   -83,  -451,  -451,    44,    74,   163,  -451,   973,
    -451,  -451,   207,   869,   298,    63,   973,  1220,   973,   139,
     206,  -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,
    -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,   298,
      20,  -451,   973,   201,  -451,  -451,  -451,  -451,   973,  -451,
    -451,  -451,   298,  -451,  -451,   210,   -11,   973,   973,   973,
    -451,   298,   298,   973,     6,  -451,   317,   949,   283,  -451,
    -451,   973,   973,   973,   298,   973,   973,   973,   973,   973,
     973,   973,   973,   973,   973,   973,   973,   973,   973,   973,
     973,   973,   973,   973,   298,   298,   298,   298,   298,   298,
     298,  -451,   216,   973,   973,    96,   105,  -451,   163,   163,
    -451,   222,  -451,   327,  -451,  -451,  -451,   217,   218,   973,
      96,   184,  -451,  -451,   331,   327,  -451,   221,   973,  -451,
    -451,  -451,   317,    11,    41,    52,    55,   973,   337,   258,
      59,    61,   282,   317,   249,  -451,  -451,  -451,  -451,  -451,
    -451,  -451,   973,    79,   305,   249,   305,   259,  -451,  -451,
    -451,  -451,   298,  -451,  -451,  -451,  -451,   356,  -451,   370,
    -451,   973,  -451,  -451,   362,  -451,  -451,   373,  -451,  -451,
     973,  -451,    20,  -451,  -451,  -451,  -451,  -451,    62,  1008,
    1067,   104,   209,   308,   337,  -451,   315,    66,  1126,   146,
    -451,  1310,  1310,   308,   308,  1310,   159,   159,   159,   159,
     159,    97,   308,   159,  1310,  1310,    97,   308,   308,   -14,
     -14,   -14,  -451,   -14,   -14,   -14,  -451,    72,  -451,    45,
    -451,  -451,  -451,   973,  -451,  -451,   330,   281,    75,  -451,
     973,   201,  -451,  -451,  -451,   973,  -451,   298,  -451,  -451,
    -451,  -451,  -451,  -451,  -451,   382,   973,  -451,  -451,   209,
    -451,  -451,  -451,  -451,  -451,   973,   197,   385,   869,   385,
     973,  -451,  1307,   312,  -451,  -451,  -451,   869,   973,  -451,
     973,  -451,  -451,  -451,  -451,   973,  -451,  -451,  -451,  -451,
     973,  -451,   973,   973,  -451,  -451,   384,  -451,  -451,   386,
    -451,  -451,  -451,    14,   163,   163,   273,   163,    76,  -451,
    -451,  -451,    56,  -451,  -451,    56,  -451,  -451,   973,  -451,
     298,  -451,    20,  -451,  1185,  -451,  -451,  -451,  -451,    25,
    -451,  -451,   973,  -451,  -451,  -451,  -451,   197,  -451,   353,
     298,   355,  -451,  -451,   973,  -451,  -451,  -451,   973,  -451,
    -451,  -451,   300,  -451,   298,  -451,   298,  -451,   319,   973,
     362,  -451,  -451,  -451,  -451,  -451,   869,  -451
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int16 yydefact[] =
{
       0,     0,    41,     0,   310,    20,     0,    29,     0,   282,
      29,   104,   306,     0,     0,   105,     0,   163,    29,     0,
     354,     0,    17,   103,     0,     0,   106,   174,    10,   308,
      37,   306,   107,   302,     0,    16,   354,    18,     0,     0,
     175,   302,     0,     0,     0,     0,     0,   233,   317,   321,
      44,     8,     0,     0,     7,     4,    11,     6,    88,    59,
      61,    60,    76,    69,    62,    64,    84,    65,    63,    66,
      67,    68,    70,    71,    72,   170,    73,    74,    75,    77,
      78,    79,    80,    81,    82,    83,    85,    87,   219,   221,
     316,     0,   315,     0,   320,     3,     0,    38,    19,     0,
       0,   287,     0,   293,     0,   289,   112,   277,   279,   283,
     309,     0,     0,     0,     0,   271,     0,   274,     0,     0,
     267,   266,   316,     0,   238,     0,   268,     0,    30,    21,
     116,   345,   346,     0,   127,   129,     0,   281,   117,    22,
     305,    15,    14,   148,   344,   157,   159,   341,   343,     0,
       0,     0,   161,    25,    24,    27,   123,   119,   121,   137,
     353,    13,   114,     0,   169,     0,   307,     0,    34,    23,
     186,   301,   236,   237,   277,   187,   113,   188,    12,   190,
     189,   191,   350,   192,   194,     0,   118,     0,   348,   348,
     348,   323,     0,     0,     0,     0,    89,    90,   300,   304,
      92,    94,   306,   102,    96,   105,     0,     0,   101,     0,
      93,    98,     0,    99,     0,   100,     0,     0,     0,   233,
       9,    42,    43,    58,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,     1,     2,     0,
     183,   179,     0,     0,   229,   230,   231,   228,     0,   224,
     225,   227,     0,   226,    40,     0,     0,     0,     0,     0,
     288,     0,     0,     0,     0,   284,   110,     0,     0,   264,
     265,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    31,    32,     0,     0,   133,     0,   130,     0,     0,
     348,     0,   162,   160,   312,   313,   314,     0,     0,     0,
     126,     0,   122,   136,     0,   185,    36,     0,     0,   197,
     196,   195,   218,     0,     0,     0,     0,     0,   236,     0,
       0,     0,   356,   115,   360,    97,   299,    91,   303,    95,
     146,   147,     0,     0,   333,   360,   333,     0,   193,   212,
     214,   210,     0,   215,   211,   213,   198,   199,   202,   200,
     206,     0,   204,   208,   358,   232,     5,     0,   180,   181,
     182,   171,   173,   220,   222,   223,    39,   291,     0,     0,
       0,     0,   278,   280,     0,   276,     0,     0,     0,     0,
     111,   245,   246,   253,   255,   249,   239,   244,   242,   243,
     241,   251,   256,   240,   247,   248,   250,   254,   252,   257,
     262,   260,   263,   261,   259,   258,    33,     0,   140,   141,
     131,   134,   135,     0,   128,   158,   341,   156,     0,   326,
       0,     0,    26,    28,   124,     0,   120,     0,    35,   349,
     347,   235,   234,   319,   318,   296,   297,   294,   325,   322,
     355,   108,   359,   144,   145,     0,     0,   364,   352,   364,
       0,   209,     0,     0,   203,   207,   357,   352,     0,   178,
       0,   290,   285,   292,   286,     0,   272,   275,   270,   269,
       0,   138,     0,     0,   132,   342,     0,   311,   125,     0,
     298,   295,   324,     0,     0,     0,     0,     0,     0,   335,
     336,   363,   331,   351,   155,   331,   217,   201,     0,   205,
       0,   216,   183,   177,     0,   139,   143,   142,   327,     0,
     151,   150,     0,   340,   338,   339,   337,     0,   332,     0,
       0,     0,   154,   184,   182,   172,   273,   167,     0,   165,
     166,   164,   153,   334,     0,   328,     0,   176,   362,     0,
     358,   329,   330,   361,   168,   152,   352,   149
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -451,  -451,  -451,   187,  -451,  -451,   241,  -451,  -451,  -451,
    -451,     8,  -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,
    -451,  -451,  -451,  -451,  -451,  -451,    88,  -451,  -451,   107,
      92,  -451,   114,  -451,   -75,  -451,  -451,  -451,  -451,  -451,
    -451,  -451,  -451,  -451,  -451,   111,  -451,  -451,  -451,  -451,
    -451,  -451,  -451,  -451,   182,  -367,   -95,  -451,  -451,  -451,
    -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,  -451,
    -451,  -451,  -451,   -44,  -451,   -43,  -220,  -451,  -451,  -451,
    -451,  -451,   189,  -451,  -451,   -84,  -451,  -451,     2,   -20,
      40,   342,    54,     3,  -451,   172,  -451,   -45,  -451,  -451,
     396,  -451,   -17,  -451,  -451,   274,    -3,  -134,     0,  -132,
       1,   134,   -71,    89,  -451,   -91,  -297,   -13,    -1,  -167,
     -49,  -450,   411,  -451,  -112,    98,  -451,   -18
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,    52,    53,    54,    55,    56,   129,   169,    98,   220,
     221,   513,   223,    58,   224,    59,    60,    61,    62,    63,
     225,    64,    65,    66,    67,   157,   158,    68,   134,   135,
     433,   322,   305,   427,   428,   226,   227,   352,    69,   228,
     532,   560,   229,   230,    70,   145,    71,   151,    72,   551,
      73,    74,    75,   522,   240,   380,   381,   231,    76,    77,
      78,    79,    80,    81,    82,    83,   232,    84,    85,   331,
     233,   366,   367,   368,   369,   370,   371,   234,   235,    86,
      87,    88,    89,   248,   252,   249,   250,   236,   122,   182,
     172,   124,   173,   125,   138,   108,   260,   265,   339,   345,
     175,   347,   141,   165,   111,   313,   314,    91,   126,    93,
     109,   152,   542,   467,   508,   509,   146,   436,   148,   333,
     183,   514,   161,   461,   477,   463,   564,   512
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      92,    94,    90,   147,   191,   155,   107,   136,    57,   253,
     107,   435,   107,   171,   170,   480,   143,   315,   159,   316,
     337,   171,   335,   340,   107,   149,   450,   521,   107,   -86,
     547,   315,    96,   316,   167,   378,   174,   107,   107,   530,
     127,   107,   107,   140,   174,   174,   123,   309,   107,   142,
      92,    94,    90,    95,   492,   241,   328,   106,   222,   493,
      47,   130,   266,   137,   346,   262,   160,   450,   262,   112,
     328,   113,   353,  -109,   450,   162,   328,   328,   174,   164,
     110,   328,   539,   184,   387,   114,   244,   490,   176,   177,
     450,   537,   179,   180,   263,   163,   310,   263,   350,   186,
     115,   -86,   256,   540,   128,   149,   451,   185,   150,   548,
     549,   116,   100,   188,   174,   268,   567,   237,   -86,   278,
     279,   379,   247,   531,   117,   101,   118,   102,   119,   103,
     104,   120,    47,    48,    49,   121,   452,   105,   332,   334,
     336,   341,   550,   438,   343,  -109,    97,   453,   168,   189,
     454,    92,    94,   375,   458,   544,   459,   481,   541,   351,
     329,   487,  -109,   166,   287,    92,    94,   491,   431,   510,
     495,   538,   342,   190,   330,   244,   251,   292,   303,   303,
     187,   278,   279,   262,   238,   349,   348,   304,   319,   311,
     174,   174,   174,   174,   354,   174,   174,   107,    92,   484,
      47,    48,   188,   324,   432,   293,    92,   243,   388,   242,
     536,   247,   263,    92,    94,    90,   254,   107,   255,   127,
     174,   357,   241,   397,   286,   262,   287,   244,   245,   246,
     338,   131,   132,   133,   257,   344,   439,   440,   291,   292,
     510,   489,   107,    92,    94,   174,   258,   504,   130,   355,
     307,   139,   518,   520,   263,   107,   358,   372,   374,   154,
     174,   259,   261,   247,   391,   505,   275,   293,   177,   465,
     320,   373,   264,   323,   271,   174,   272,   399,   273,   506,
     131,   132,   144,   128,   507,   153,   274,   301,   384,   131,
     132,   144,   302,   377,   306,   303,   308,   419,   420,   421,
     422,   423,   424,   425,   394,   136,   385,   315,   449,   316,
     131,   132,   156,   312,   326,   400,   317,   318,   276,   277,
     159,   321,   327,   131,   132,   144,   294,    47,    48,    49,
     485,   174,   328,   356,   295,   296,    51,   278,   279,   386,
     297,   298,   441,   429,   430,   426,   447,   299,   442,   443,
     448,   456,   300,   457,   460,   359,   462,   280,   281,   444,
     479,    99,   262,   360,   361,   107,   282,   283,   466,   362,
     363,   472,   470,   284,   174,    99,   364,   455,   387,   285,
     286,   365,   287,   174,   288,   473,   476,   478,   292,   289,
     290,   263,   464,   310,   291,   292,   500,   511,   528,   535,
     554,   529,   556,   559,   100,   563,    99,   376,   127,   446,
     486,   474,   445,   434,   502,   525,   471,   101,   100,   102,
     437,   103,   104,   293,   382,   475,    49,   545,   517,   105,
     519,   101,   383,   102,   392,   103,   104,   181,   497,   325,
      49,    92,    94,   105,   543,   469,   553,   178,   566,   100,
     107,   515,     0,   468,   267,   269,   270,     0,     0,     0,
     479,     0,   101,     0,   102,     0,   103,   104,    92,    94,
      90,    49,   128,   494,   105,     0,   107,    92,    94,    90,
     496,     0,     0,   174,     0,   498,     0,     0,     0,     0,
       0,   533,   534,     0,     0,     0,   501,     0,     0,   294,
       0,   499,     0,     0,     0,   503,     0,   295,   296,     0,
     516,     0,   372,   297,   298,     0,     0,     0,   523,     0,
     299,     0,     0,   107,     0,   300,     0,   373,     0,     0,
     429,     0,   526,   527,     0,   262,     0,     0,     0,     0,
       0,     0,     0,   107,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   107,   474,   107,
       0,     0,     0,     0,   263,     0,    92,    94,    90,     0,
       0,     0,   552,     0,   475,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   557,     0,     0,     0,   558,     0,
       0,     0,     0,     0,   555,     0,     0,     0,     0,   565,
     389,   390,     0,     0,     0,   393,     0,     0,   561,     0,
     562,     0,     0,   396,     0,   398,     0,     0,   401,   402,
     403,   404,   405,   406,   407,   408,   409,   410,   411,   412,
     413,   414,   415,   416,   417,   418,     1,     0,     0,     0,
       0,     2,     0,     0,     0,     0,     3,     0,     4,     0,
       0,     5,     6,     0,     7,     8,     9,     0,     0,     0,
       0,     0,    10,     0,     0,     0,     0,     0,     0,     0,
       0,    11,     0,     0,    12,    13,    -9,     0,     0,     0,
      14,    15,     0,     0,     0,     0,     0,     0,     0,     0,
      16,    17,     0,     0,    18,    19,    20,     0,     0,     0,
       0,    21,     0,     0,     0,    22,    23,     0,    24,     0,
       0,    25,     0,    26,     0,     0,    27,     0,    28,     0,
      29,     0,     0,    30,     0,    31,    32,    33,    34,     0,
       0,    35,    36,    37,    38,    39,    40,     0,     0,    41,
      42,     0,     0,     0,     0,    43,    44,    45,     0,     0,
       0,     0,    46,     0,     0,     0,     0,     0,     0,     0,
       0,    47,    48,    49,    50,    51,     0,   192,     3,     0,
       4,     0,     0,     0,     6,   193,   194,     8,     9,     0,
       0,     0,     0,     0,     0,   195,   196,   197,   198,   199,
     200,   201,   202,    11,   203,   204,     0,     0,     0,     0,
       0,     0,    14,   205,     0,     0,   206,   207,     0,     0,
     208,   209,    16,    17,     0,     0,     0,    19,     0,   210,
       0,     0,     0,    21,     0,     0,     0,   524,    23,     0,
      24,     0,     0,    25,   211,    26,     0,     0,    27,   212,
       0,     0,    29,     0,     0,     0,   213,    31,    32,    33,
      34,     0,     0,   214,     0,     0,    38,    39,    40,     0,
       0,    41,    42,     0,     0,     0,     0,    43,   215,    45,
     216,     0,   217,   218,    46,     0,     0,     0,     0,     0,
       3,     0,     4,   219,    48,    49,     6,     0,   194,     8,
       9,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    11,     0,     0,     0,     0,
       0,     0,     0,     0,    14,    15,     0,     0,     0,     0,
       0,     0,     0,     0,    16,    17,     0,     0,     0,    19,
       0,     0,     0,     0,     0,    21,     0,     0,     0,     0,
      23,     0,    24,     0,     0,    25,     0,    26,     0,     0,
      27,     0,   276,   277,    29,     0,     0,     0,     0,    31,
      32,    33,    34,     0,     0,   214,     0,     0,    38,    39,
      40,   278,   279,    41,    42,     0,     0,     0,     0,    43,
      44,    45,     0,     0,     0,     0,    46,     0,     0,     0,
       0,   280,   281,     0,     0,    47,    48,    49,     0,     0,
     282,   283,     0,     0,     0,     0,     0,   284,     0,     0,
       0,   276,   277,   285,   286,     0,   287,     0,   288,     0,
       0,     0,     0,   289,   290,     0,     0,     0,   291,   292,
     278,   279,     0,     0,     0,     0,   112,     0,   113,     0,
       0,     0,     0,     0,   395,     0,     0,     0,     0,     0,
     280,   281,   114,     0,     0,     0,     0,   293,     0,   282,
     283,     0,     0,     0,     0,     0,   284,   115,     0,     0,
     276,   277,   285,   286,     0,   287,     0,   288,   116,   100,
       0,     0,   289,   290,     0,     0,     0,   291,   292,   278,
     279,   117,   101,   118,   102,   119,   103,   104,   120,    47,
      48,    49,   121,   482,   105,     0,     0,     0,     0,   280,
     281,     0,     0,     0,     0,     0,   293,     0,   282,   283,
       0,     0,     0,     0,     0,   284,     0,     0,     0,   276,
     277,   285,   286,     0,   287,     0,   288,     0,     0,     0,
       0,   289,   290,     0,     0,     0,   291,   292,   278,   279,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   483,     0,     0,     0,     0,     0,   280,   281,
       0,     0,     0,     0,     0,   293,     0,   282,   283,     0,
       0,     0,     0,     0,   284,     0,     0,     0,   276,   277,
     285,   286,     0,   287,     0,   288,     0,     0,     0,     0,
     289,   290,     0,     0,     0,   291,   292,   278,   279,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   488,     0,     0,     0,     0,     0,   280,   281,     0,
       0,     0,     0,     0,   293,     0,   282,   283,     0,     0,
       0,     0,     0,   284,     0,     0,     0,   276,   277,   285,
     286,     0,   287,     0,   288,     0,     0,     0,     0,   289,
     290,     0,     0,   359,   291,   292,   278,   279,     0,     0,
       0,   360,   361,     0,     0,     0,     0,   362,   363,     0,
     546,     0,     0,   112,   364,   113,   280,   281,     0,   365,
       0,     0,     0,   293,     0,   282,   283,     0,     0,   114,
       0,     0,   284,     0,     0,     0,     0,     0,   285,   286,
       0,   287,     0,   288,   115,     0,     0,     0,   289,   290,
       0,     0,     0,   291,   292,   116,   100,     0,     0,     0,
       0,     0,   278,   279,     0,     0,     0,     0,   117,   101,
     118,   102,   119,   103,   104,   120,    47,    48,    49,   121,
     359,   105,   293,   281,     0,     0,     0,     0,   360,   361,
       0,   282,   283,     0,     0,   363,     0,     0,   284,     0,
     112,   364,   113,     0,   285,   286,   365,   287,     0,   288,
       0,     0,     0,     0,     0,     0,   114,     0,     0,   291,
     292,   149,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   115,     0,     0,     0,     0,   112,     0,   113,     0,
       0,     0,   116,   100,     0,     0,     0,     0,   293,     0,
       0,     0,   114,     0,     0,   117,   101,   118,   102,   119,
     103,   104,   120,    47,    48,    49,   121,   115,   105,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   116,   100,
       0,     0,     0,     0,     0,     0,     0,   239,     0,     0,
       0,   117,   101,   118,   102,   119,   103,   104,   120,    47,
      48,    49,   121,     0,   105
};

static const yytype_int16 yycheck[] =
{
       0,     0,     0,    16,    49,    18,     3,     8,     0,    93,
       7,   308,     9,    33,    31,   382,    14,   151,    19,   151,
      14,    41,   189,   190,    21,    48,    15,   477,    25,    41,
       5,   165,    15,   165,    15,    15,    33,    34,    35,    25,
      65,    38,    39,   126,    41,    42,     6,    14,    45,   131,
      50,    50,    50,    41,     9,    75,    15,     3,    50,    14,
     126,     7,   111,     9,   198,    79,   131,    15,    79,    63,
      15,    65,   206,    41,    15,    21,    15,    15,    75,    25,
      48,    15,    26,    43,    95,    79,     7,    15,    34,    35,
      15,    15,    38,    39,   108,    48,    63,   108,    54,    45,
      94,   113,    99,    47,   129,    48,    95,    44,   131,    84,
      85,   105,   106,    63,   111,   112,   566,     0,   130,    22,
      23,   101,    43,   109,   118,   119,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,    95,   131,   187,   188,
     189,   190,   117,   310,   193,   113,   129,    95,   129,    63,
      95,   151,   151,    14,    95,   522,    95,    95,   102,   115,
      65,    95,   130,    29,    67,   165,   165,    95,    72,   466,
      95,    95,   192,    63,    79,     7,     8,    80,    63,    63,
      46,    22,    23,    79,    41,   202,   199,    72,    72,   149,
     187,   188,   189,   190,   207,   192,   193,   194,   198,    95,
     126,   127,    63,   163,   108,   108,   206,   101,   257,    75,
     507,    43,   108,   213,   213,   213,   129,   214,    15,    65,
     217,   213,   242,   272,    65,    79,    67,     7,     8,     9,
     190,   126,   127,   128,    63,   195,    14,    15,    79,    80,
     537,    95,   239,   243,   243,   242,    63,    50,   194,   209,
     136,    10,   472,   473,   108,   252,   216,   217,   218,    18,
     257,    63,    63,    43,   261,    68,    15,   108,   214,   353,
     156,   217,    63,   159,    63,   272,    63,   274,    63,    82,
     126,   127,   128,   129,    87,   131,    63,   129,   248,   126,
     127,   128,    65,   239,    15,    63,    15,   294,   295,   296,
     297,   298,   299,   300,   264,   306,   252,   441,   328,   441,
     126,   127,   128,    14,   129,   275,    15,    15,     3,     4,
     321,    15,    15,   126,   127,   128,    43,   126,   127,   128,
      15,   328,    15,   126,    51,    52,   130,    22,    23,   129,
      57,    58,    15,   303,   304,   129,    15,    64,   131,   131,
     129,    14,    69,    95,    72,    43,   107,    42,    43,   319,
     380,    63,    79,    51,    52,   362,    51,    52,    63,    57,
      58,    15,   113,    58,   371,    63,    64,   337,    95,    64,
      65,    69,    67,   380,    69,    15,    24,    14,    80,    74,
      75,   108,   352,    63,    79,    80,    14,    12,    14,   126,
      47,    15,    47,   103,   106,    86,    63,   220,    65,   321,
      95,   371,   320,   306,   459,   490,   362,   119,   106,   121,
     309,   123,   124,   108,   242,   371,   128,   522,   472,   131,
     473,   119,   243,   121,   262,   123,   124,    41,   441,   165,
     128,   441,   441,   131,   515,   356,   537,    36,   560,   106,
     447,   469,    -1,   355,   112,   113,   114,    -1,    -1,    -1,
     480,    -1,   119,    -1,   121,    -1,   123,   124,   468,   468,
     468,   128,   129,   433,   131,    -1,   473,   477,   477,   477,
     440,    -1,    -1,   480,    -1,   445,    -1,    -1,    -1,    -1,
      -1,   504,   505,    -1,    -1,    -1,   456,    -1,    -1,    43,
      -1,   447,    -1,    -1,    -1,   465,    -1,    51,    52,    -1,
     470,    -1,   472,    57,    58,    -1,    -1,    -1,   478,    -1,
      64,    -1,    -1,   520,    -1,    69,    -1,   473,    -1,    -1,
     490,    -1,   492,   493,    -1,    79,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   540,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   554,   518,   556,
      -1,    -1,    -1,    -1,   108,    -1,   566,   566,   566,    -1,
      -1,    -1,   532,    -1,   520,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   544,    -1,    -1,    -1,   548,    -1,
      -1,    -1,    -1,    -1,   540,    -1,    -1,    -1,    -1,   559,
     258,   259,    -1,    -1,    -1,   263,    -1,    -1,   554,    -1,
     556,    -1,    -1,   271,    -1,   273,    -1,    -1,   276,   277,
     278,   279,   280,   281,   282,   283,   284,   285,   286,   287,
     288,   289,   290,   291,   292,   293,     1,    -1,    -1,    -1,
      -1,     6,    -1,    -1,    -1,    -1,    11,    -1,    13,    -1,
      -1,    16,    17,    -1,    19,    20,    21,    -1,    -1,    -1,
      -1,    -1,    27,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    36,    -1,    -1,    39,    40,    41,    -1,    -1,    -1,
      45,    46,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      55,    56,    -1,    -1,    59,    60,    61,    -1,    -1,    -1,
      -1,    66,    -1,    -1,    -1,    70,    71,    -1,    73,    -1,
      -1,    76,    -1,    78,    -1,    -1,    81,    -1,    83,    -1,
      85,    -1,    -1,    88,    -1,    90,    91,    92,    93,    -1,
      -1,    96,    97,    98,    99,   100,   101,    -1,    -1,   104,
     105,    -1,    -1,    -1,    -1,   110,   111,   112,    -1,    -1,
      -1,    -1,   117,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   126,   127,   128,   129,   130,    -1,    10,    11,    -1,
      13,    -1,    -1,    -1,    17,    18,    19,    20,    21,    -1,
      -1,    -1,    -1,    -1,    -1,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    -1,    -1,    -1,    -1,
      -1,    -1,    45,    46,    -1,    -1,    49,    50,    -1,    -1,
      53,    54,    55,    56,    -1,    -1,    -1,    60,    -1,    62,
      -1,    -1,    -1,    66,    -1,    -1,    -1,   485,    71,    -1,
      73,    -1,    -1,    76,    77,    78,    -1,    -1,    81,    82,
      -1,    -1,    85,    -1,    -1,    -1,    89,    90,    91,    92,
      93,    -1,    -1,    96,    -1,    -1,    99,   100,   101,    -1,
      -1,   104,   105,    -1,    -1,    -1,    -1,   110,   111,   112,
     113,    -1,   115,   116,   117,    -1,    -1,    -1,    -1,    -1,
      11,    -1,    13,   126,   127,   128,    17,    -1,    19,    20,
      21,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    36,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    45,    46,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    55,    56,    -1,    -1,    -1,    60,
      -1,    -1,    -1,    -1,    -1,    66,    -1,    -1,    -1,    -1,
      71,    -1,    73,    -1,    -1,    76,    -1,    78,    -1,    -1,
      81,    -1,     3,     4,    85,    -1,    -1,    -1,    -1,    90,
      91,    92,    93,    -1,    -1,    96,    -1,    -1,    99,   100,
     101,    22,    23,   104,   105,    -1,    -1,    -1,    -1,   110,
     111,   112,    -1,    -1,    -1,    -1,   117,    -1,    -1,    -1,
      -1,    42,    43,    -1,    -1,   126,   127,   128,    -1,    -1,
      51,    52,    -1,    -1,    -1,    -1,    -1,    58,    -1,    -1,
      -1,     3,     4,    64,    65,    -1,    67,    -1,    69,    -1,
      -1,    -1,    -1,    74,    75,    -1,    -1,    -1,    79,    80,
      22,    23,    -1,    -1,    -1,    -1,    63,    -1,    65,    -1,
      -1,    -1,    -1,    -1,    95,    -1,    -1,    -1,    -1,    -1,
      42,    43,    79,    -1,    -1,    -1,    -1,   108,    -1,    51,
      52,    -1,    -1,    -1,    -1,    -1,    58,    94,    -1,    -1,
       3,     4,    64,    65,    -1,    67,    -1,    69,   105,   106,
      -1,    -1,    74,    75,    -1,    -1,    -1,    79,    80,    22,
      23,   118,   119,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,    95,   131,    -1,    -1,    -1,    -1,    42,
      43,    -1,    -1,    -1,    -1,    -1,   108,    -1,    51,    52,
      -1,    -1,    -1,    -1,    -1,    58,    -1,    -1,    -1,     3,
       4,    64,    65,    -1,    67,    -1,    69,    -1,    -1,    -1,
      -1,    74,    75,    -1,    -1,    -1,    79,    80,    22,    23,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    95,    -1,    -1,    -1,    -1,    -1,    42,    43,
      -1,    -1,    -1,    -1,    -1,   108,    -1,    51,    52,    -1,
      -1,    -1,    -1,    -1,    58,    -1,    -1,    -1,     3,     4,
      64,    65,    -1,    67,    -1,    69,    -1,    -1,    -1,    -1,
      74,    75,    -1,    -1,    -1,    79,    80,    22,    23,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    95,    -1,    -1,    -1,    -1,    -1,    42,    43,    -1,
      -1,    -1,    -1,    -1,   108,    -1,    51,    52,    -1,    -1,
      -1,    -1,    -1,    58,    -1,    -1,    -1,     3,     4,    64,
      65,    -1,    67,    -1,    69,    -1,    -1,    -1,    -1,    74,
      75,    -1,    -1,    43,    79,    80,    22,    23,    -1,    -1,
      -1,    51,    52,    -1,    -1,    -1,    -1,    57,    58,    -1,
      95,    -1,    -1,    63,    64,    65,    42,    43,    -1,    69,
      -1,    -1,    -1,   108,    -1,    51,    52,    -1,    -1,    79,
      -1,    -1,    58,    -1,    -1,    -1,    -1,    -1,    64,    65,
      -1,    67,    -1,    69,    94,    -1,    -1,    -1,    74,    75,
      -1,    -1,    -1,    79,    80,   105,   106,    -1,    -1,    -1,
      -1,    -1,    22,    23,    -1,    -1,    -1,    -1,   118,   119,
     120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
      43,   131,   108,    43,    -1,    -1,    -1,    -1,    51,    52,
      -1,    51,    52,    -1,    -1,    58,    -1,    -1,    58,    -1,
      63,    64,    65,    -1,    64,    65,    69,    67,    -1,    69,
      -1,    -1,    -1,    -1,    -1,    -1,    79,    -1,    -1,    79,
      80,    48,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    94,    -1,    -1,    -1,    -1,    63,    -1,    65,    -1,
      -1,    -1,   105,   106,    -1,    -1,    -1,    -1,   108,    -1,
      -1,    -1,    79,    -1,    -1,   118,   119,   120,   121,   122,
     123,   124,   125,   126,   127,   128,   129,    94,   131,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   105,   106,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   114,    -1,    -1,
      -1,   118,   119,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,    -1,   131
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int16 yystos[] =
{
       0,     1,     6,    11,    13,    16,    17,    19,    20,    21,
      27,    36,    39,    40,    45,    46,    55,    56,    59,    60,
      61,    66,    70,    71,    73,    76,    78,    81,    83,    85,
      88,    90,    91,    92,    93,    96,    97,    98,    99,   100,
     101,   104,   105,   110,   111,   112,   117,   126,   127,   128,
     129,   130,   134,   135,   136,   137,   138,   144,   146,   148,
     149,   150,   151,   152,   154,   155,   156,   157,   160,   171,
     177,   179,   181,   183,   184,   185,   191,   192,   193,   194,
     195,   196,   197,   198,   200,   201,   212,   213,   214,   215,
     221,   240,   241,   242,   243,    41,    15,   129,   141,    63,
     106,   119,   121,   123,   124,   131,   225,   226,   228,   243,
      48,   237,    63,    65,    79,    94,   105,   118,   120,   122,
     125,   129,   221,   223,   224,   226,   241,    65,   129,   139,
     225,   126,   127,   128,   161,   162,   251,   225,   227,   139,
     126,   235,   131,   221,   128,   178,   249,   250,   251,    48,
     131,   180,   244,   131,   139,   250,   128,   158,   159,   251,
     131,   255,   225,    48,   225,   236,   244,    15,   129,   140,
     235,   222,   223,   225,   226,   233,   225,   225,   255,   225,
     225,   233,   222,   253,   223,    44,   225,   244,    63,    63,
      63,   230,    10,    18,    19,    28,    29,    30,    31,    32,
      33,    34,    35,    37,    38,    46,    49,    50,    53,    54,
      62,    77,    82,    89,    96,   111,   113,   115,   116,   126,
     142,   143,   144,   145,   147,   153,   168,   169,   172,   175,
     176,   190,   199,   203,   210,   211,   220,     0,    41,   114,
     187,   222,   244,   101,     7,     8,     9,    43,   216,   218,
     219,     8,   217,   218,   129,    15,   226,    63,    63,    63,
     229,    63,    79,   108,    63,   230,   253,   224,   226,   224,
     224,    63,    63,    63,    63,    15,     3,     4,    22,    23,
      42,    43,    51,    52,    58,    64,    65,    67,    69,    74,
      75,    79,    80,   108,    43,    51,    52,    57,    58,    64,
      69,   129,    65,    63,    72,   165,    15,   165,    15,    14,
      63,   223,    14,   238,   239,   240,   242,    15,    15,    72,
     165,    15,   164,   165,   223,   238,   129,    15,    15,    65,
      79,   202,   253,   252,   253,   252,   253,    14,   223,   231,
     252,   253,   222,   253,   223,   232,   240,   234,   250,   235,
      54,   115,   170,   240,   250,   223,   126,   144,   223,    43,
      51,    52,    57,    58,    64,    69,   204,   205,   206,   207,
     208,   209,   223,   225,   223,    14,   136,   225,    15,   101,
     188,   189,   187,   215,   223,   225,   129,    95,   253,   224,
     224,   226,   228,   224,   223,    95,   224,   253,   224,   226,
     223,   224,   224,   224,   224,   224,   224,   224,   224,   224,
     224,   224,   224,   224,   224,   224,   224,   224,   224,   226,
     226,   226,   226,   226,   226,   226,   129,   166,   167,   223,
     223,    72,   108,   163,   162,   249,   250,   178,   252,    14,
      15,    15,   131,   131,   223,   163,   159,    15,   129,   222,
      15,    95,    95,    95,    95,   223,    14,    95,    95,    95,
      72,   256,   107,   258,   223,   218,    63,   246,   258,   246,
     113,   225,    15,    15,   223,   225,    24,   257,    14,   222,
     188,    95,    95,    95,    95,    15,    95,    95,    95,    95,
      15,    95,     9,    14,   223,    95,   223,   239,   223,   225,
      14,   223,   230,   223,    50,    68,    82,    87,   247,   248,
     249,    12,   260,   144,   254,   260,   223,   206,   209,   208,
     209,   254,   186,   223,   224,   167,   223,   223,    14,    15,
      25,   109,   173,   250,   250,   126,   249,    15,    95,    26,
      47,   102,   245,   245,   188,   189,    95,     5,    84,    85,
     117,   182,   223,   248,    47,   225,    47,   223,   223,   103,
     174,   225,   225,    86,   259,   223,   257,   254
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int16 yyr1[] =
{
       0,   133,   134,   134,   135,   135,   135,   135,   136,   136,
     137,   137,   137,   137,   137,   137,   137,   137,   137,   137,
     137,   137,   137,   137,   138,   138,   138,   138,   138,   139,
     139,   139,   139,   139,   140,   140,   140,   140,   141,   141,
     141,   141,   142,   142,   142,   143,   143,   143,   143,   143,
     143,   143,   143,   143,   143,   143,   143,   143,   143,   144,
     144,   144,   144,   144,   144,   144,   144,   144,   144,   144,
     144,   144,   144,   144,   144,   144,   144,   144,   144,   144,
     144,   144,   144,   144,   144,   144,   144,   144,   144,   145,
     145,   145,   145,   145,   145,   145,   145,   145,   145,   145,
     145,   145,   145,   146,   146,   146,   146,   146,   147,   148,
     148,   149,   150,   151,   152,   153,   154,   155,   156,   157,
     158,   158,   159,   159,   159,   159,   159,   160,   161,   161,
     162,   162,   162,   162,   163,   163,   164,   164,   165,   166,
     166,   167,   167,   167,   168,   169,   170,   170,   171,   172,
     173,   173,   174,   174,   175,   176,   177,   177,   178,   178,
     179,   180,   180,   180,   181,   182,   182,   182,   182,   183,
     184,   184,   184,   184,   185,   185,   186,   186,   187,   187,
     188,   188,   189,   189,   190,   191,   192,   193,   194,   195,
     196,   197,   198,   199,   200,   201,   202,   202,   203,   204,
     204,   205,   205,   206,   206,   207,   207,   208,   208,   208,
     209,   209,   209,   209,   209,   209,   210,   211,   212,   213,
     214,   214,   215,   215,   216,   216,   217,   217,   218,   218,
     219,   219,   220,   221,   221,   221,   222,   222,   223,   224,
     224,   224,   224,   224,   224,   224,   224,   224,   224,   224,
     224,   224,   224,   224,   224,   224,   224,   224,   224,   224,
     224,   224,   224,   224,   224,   224,   224,   224,   224,   224,
     224,   224,   224,   224,   224,   224,   224,   225,   226,   226,
     226,   227,   227,   228,   228,   228,   228,   228,   228,   228,
     228,   228,   229,   229,   230,   231,   231,   231,   231,   232,
     232,   233,   233,   234,   234,   235,   235,   236,   236,   237,
     237,   238,   238,   239,   239,   240,   241,   241,   241,   241,
     242,   243,   243,   243,   243,   243,   244,   244,   245,   245,
     245,   245,   246,   246,   247,   247,   248,   248,   248,   248,
     248,   249,   249,   250,   250,   251,   251,   252,   252,   253,
     253,   254,   254,   255,   255,   256,   256,   257,   257,   258,
     258,   259,   259,   260,   260
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     2,     2,     1,     3,     1,     1,     1,     0,
       1,     1,     2,     2,     2,     2,     1,     1,     1,     2,
       1,     2,     2,     2,     2,     2,     4,     2,     4,     0,
       1,     2,     2,     3,     1,     3,     2,     0,     1,     3,
       2,     0,     1,     1,     0,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     1,     1,     1,     2,     1,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     3,     1,
       3,     4,     2,     2,     2,     2,     2,     2,     2,     2,
       3,     1,     2,     1,     3,     4,     2,     2,     3,     1,
       2,     3,     4,     2,     1,     1,     1,     0,     3,     3,
       1,     1,     3,     3,     3,     3,     1,     1,     2,     9,
       1,     1,     2,     0,     5,     4,     4,     2,     3,     1,
       3,     1,     2,     0,     7,     1,     1,     1,     3,     2,
       1,     3,     6,     3,     1,     1,     3,     1,     3,     1,
       1,     1,     1,     0,     5,     3,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     3,     1,     1,     2,     1,
       1,     3,     1,     2,     1,     3,     1,     2,     1,     2,
       1,     1,     1,     1,     1,     1,     4,     4,     3,     1,
       3,     1,     3,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     1,     4,     4,     1,     1,     1,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     2,     2,     1,     1,     1,     4,
       4,     1,     4,     6,     1,     4,     3,     1,     3,     1,
       3,     1,     0,     1,     2,     4,     4,     1,     2,     1,
       4,     3,     3,     0,     3,     3,     2,     2,     3,     1,
       0,     1,     0,     1,     0,     1,     0,     1,     0,     1,
       0,     3,     1,     1,     1,     1,     1,     1,     4,     4,
       1,     1,     4,     2,     5,     4,     3,     5,     2,     3,
       3,     0,     3,     0,     3,     1,     1,     2,     2,     2,
       2,     1,     4,     1,     1,     1,     1,     2,     0,     3,
       1,     1,     0,     1,     0,     1,     0,     1,     0,     1,
       0,     1,     0,     1,     0
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* a_comal_line: comal_line eolnSYM  */
#line 236 "pdcpars.y"
                        {
				c_line=(yyvsp[-1].cl);
				YYACCEPT;
			}
#line 1996 "pdcpars.tab.c"
    break;

  case 3: /* a_comal_line: error eolnSYM  */
#line 241 "pdcpars.y"
                        {
				p_error("Syntax error");
				yyerrok;
				c_line.cmd=0;
				YYACCEPT;
			}
#line 2007 "pdcpars.tab.c"
    break;

  case 4: /* comal_line: command  */
#line 250 "pdcpars.y"
                        {
				(yyval.cl)=(yyvsp[0].cl);
				(yyval.cl).ld=NULL;
			}
#line 2016 "pdcpars.tab.c"
    break;

  case 5: /* comal_line: intnumSYM program_line optrem  */
#line 255 "pdcpars.y"
                        {
				(yyval.cl)=(yyvsp[-1].cl);
				(yyval.cl).ld=mem_alloc(PARSE_POOL,sizeof(struct comal_line_data));
				(yyval.cl).ld->lineno=(yyvsp[-2].num);
				(yyval.cl).ld->rem=(yyvsp[0].str);
				(yyval.cl).lineptr=NULL;
			}
#line 2028 "pdcpars.tab.c"
    break;

  case 6: /* comal_line: simple_stat  */
#line 263 "pdcpars.y"
                        {
				(yyval.cl)=(yyvsp[0].cl);
				(yyval.cl).ld=NULL;
			}
#line 2037 "pdcpars.tab.c"
    break;

  case 7: /* comal_line: optrem  */
#line 268 "pdcpars.y"
                        {
				(yyval.cl).cmd=0;
			}
#line 2045 "pdcpars.tab.c"
    break;

  case 9: /* optrem: %empty  */
#line 275 "pdcpars.y"
                        {
				(yyval.str)=NULL;
			}
#line 2053 "pdcpars.tab.c"
    break;

  case 10: /* command: quitSYM  */
#line 282 "pdcpars.y"
                        {
				(yyval.cl).cmd=quitSYM;
			}
#line 2061 "pdcpars.tab.c"
    break;

  case 12: /* command: saveSYM optfilename  */
#line 287 "pdcpars.y"
                        {
				(yyval.cl).cmd=saveSYM;
				(yyval.cl).lc.str=(yyvsp[0].str);
			}
#line 2070 "pdcpars.tab.c"
    break;

  case 13: /* command: loadSYM optfilename  */
#line 292 "pdcpars.y"
                        {
				(yyval.cl).cmd=loadSYM;
				(yyval.cl).lc.str=(yyvsp[0].str);
			}
#line 2079 "pdcpars.tab.c"
    break;

  case 14: /* command: enterSYM stringSYM  */
#line 297 "pdcpars.y"
                        {
				(yyval.cl).cmd=enterSYM;
				(yyval.cl).lc.str=(yyvsp[0].str);
			}
#line 2088 "pdcpars.tab.c"
    break;

  case 15: /* command: envSYM optid2  */
#line 302 "pdcpars.y"
                        {
				(yyval.cl).cmd=envSYM;
				(yyval.cl).lc.id=(yyvsp[0].id);
			}
#line 2097 "pdcpars.tab.c"
    break;

  case 16: /* command: runSYM  */
#line 307 "pdcpars.y"
                        {
				(yyval.cl).cmd=COMMAND(runSYM);
				(yyval.cl).lc.str=NULL;
			}
#line 2106 "pdcpars.tab.c"
    break;

  case 17: /* command: newSYM  */
#line 312 "pdcpars.y"
                        {
				(yyval.cl).cmd=newSYM;
			}
#line 2114 "pdcpars.tab.c"
    break;

  case 18: /* command: scanSYM  */
#line 316 "pdcpars.y"
                        {
				(yyval.cl).cmd=scanSYM;
			}
#line 2122 "pdcpars.tab.c"
    break;

  case 19: /* command: autoSYM autolines  */
#line 320 "pdcpars.y"
                        {
				(yyval.cl).cmd=autoSYM;
				(yyval.cl).lc.twonum=(yyvsp[0].twonum);
			}
#line 2131 "pdcpars.tab.c"
    break;

  case 20: /* command: contSYM  */
#line 325 "pdcpars.y"
                        {
				(yyval.cl).cmd=contSYM;
			}
#line 2139 "pdcpars.tab.c"
    break;

  case 21: /* command: delSYM line_range  */
#line 329 "pdcpars.y"
                        {
				(yyval.cl).cmd=COMMAND(delSYM);
				(yyval.cl).lc.twonum=(yyvsp[0].twonum);
			}
#line 2148 "pdcpars.tab.c"
    break;

  case 22: /* command: editSYM line_range  */
#line 334 "pdcpars.y"
                        {
				(yyval.cl).cmd=editSYM;
				(yyval.cl).lc.twonum=(yyvsp[0].twonum);
			}
#line 2157 "pdcpars.tab.c"
    break;

  case 23: /* command: renumberSYM renumlines  */
#line 339 "pdcpars.y"
                        {
				(yyval.cl).cmd=renumberSYM;
				(yyval.cl).lc.twonum=(yyvsp[0].twonum);
			}
#line 2166 "pdcpars.tab.c"
    break;

  case 24: /* list_cmd: listSYM line_range  */
#line 346 "pdcpars.y"
                        {
				(yyval.cl).cmd=listSYM;
				(yyval.cl).lc.listrec.str=NULL;
				(yyval.cl).lc.listrec.twonum=(yyvsp[0].twonum);
				(yyval.cl).lc.listrec.id=NULL;
			}
#line 2177 "pdcpars.tab.c"
    break;

  case 25: /* list_cmd: listSYM stringSYM  */
#line 353 "pdcpars.y"
                        {
				(yyval.cl).cmd=listSYM;
				(yyval.cl).lc.listrec.str=(yyvsp[0].str);
				(yyval.cl).lc.listrec.twonum.num1=0;
				(yyval.cl).lc.listrec.twonum.num2=INT_MAX;
				(yyval.cl).lc.listrec.id=NULL;
			}
#line 2189 "pdcpars.tab.c"
    break;

  case 26: /* list_cmd: listSYM line_range commaSYM stringSYM  */
#line 361 "pdcpars.y"
                        {
				(yyval.cl).cmd=listSYM;
				(yyval.cl).lc.listrec.str=(yyvsp[0].str);
				(yyval.cl).lc.listrec.twonum=(yyvsp[-2].twonum);
				(yyval.cl).lc.listrec.id=NULL;
			}
#line 2200 "pdcpars.tab.c"
    break;

  case 27: /* list_cmd: listSYM id  */
#line 368 "pdcpars.y"
                        {
				(yyval.cl).cmd=listSYM;
				(yyval.cl).lc.listrec.str=NULL;
				(yyval.cl).lc.listrec.id=(yyvsp[0].id);
			}
#line 2210 "pdcpars.tab.c"
    break;

  case 28: /* list_cmd: listSYM id commaSYM stringSYM  */
#line 374 "pdcpars.y"
                        {
				(yyval.cl).cmd=listSYM;
				(yyval.cl).lc.listrec.str=(yyvsp[0].str);
				(yyval.cl).lc.listrec.id=(yyvsp[-2].id);
			}
#line 2220 "pdcpars.tab.c"
    break;

  case 29: /* line_range: %empty  */
#line 382 "pdcpars.y"
                        {
				(yyval.twonum).num1=0;	(yyval.twonum).num2=INT_MAX;
			}
#line 2228 "pdcpars.tab.c"
    break;

  case 30: /* line_range: intnumSYM  */
#line 386 "pdcpars.y"
                        {
				(yyval.twonum).num1=(yyvsp[0].num);	(yyval.twonum).num2=(yyvsp[0].num);
			}
#line 2236 "pdcpars.tab.c"
    break;

  case 31: /* line_range: minusSYM intnumSYM  */
#line 390 "pdcpars.y"
                        {
				(yyval.twonum).num1=0;	(yyval.twonum).num2=(yyvsp[0].num);
			}
#line 2244 "pdcpars.tab.c"
    break;

  case 32: /* line_range: intnumSYM minusSYM  */
#line 394 "pdcpars.y"
                        {
				(yyval.twonum).num1=(yyvsp[-1].num);	(yyval.twonum).num2=INT_MAX;
			}
#line 2252 "pdcpars.tab.c"
    break;

  case 33: /* line_range: intnumSYM minusSYM intnumSYM  */
#line 398 "pdcpars.y"
                        {
				(yyval.twonum).num1=(yyvsp[-2].num);	(yyval.twonum).num2=(yyvsp[0].num);
			}
#line 2260 "pdcpars.tab.c"
    break;

  case 34: /* renumlines: intnumSYM  */
#line 404 "pdcpars.y"
                        {
				(yyval.twonum).num1=(yyvsp[0].num);	(yyval.twonum).num2=10;
			}
#line 2268 "pdcpars.tab.c"
    break;

  case 35: /* renumlines: intnumSYM commaSYM intnumSYM  */
#line 408 "pdcpars.y"
                        {
				(yyval.twonum).num1=(yyvsp[-2].num);	(yyval.twonum).num2=(yyvsp[0].num);
			}
#line 2276 "pdcpars.tab.c"
    break;

  case 36: /* renumlines: commaSYM intnumSYM  */
#line 412 "pdcpars.y"
                        {
				(yyval.twonum).num1=10;	(yyval.twonum).num2=(yyvsp[0].num);
			}
#line 2284 "pdcpars.tab.c"
    break;

  case 37: /* renumlines: %empty  */
#line 416 "pdcpars.y"
                        {
				(yyval.twonum).num1=10;	(yyval.twonum).num2=10;
			}
#line 2292 "pdcpars.tab.c"
    break;

  case 38: /* autolines: intnumSYM  */
#line 422 "pdcpars.y"
                        {
				(yyval.twonum).num1=(yyvsp[0].num);	(yyval.twonum).num2=10;
			}
#line 2300 "pdcpars.tab.c"
    break;

  case 39: /* autolines: intnumSYM commaSYM intnumSYM  */
#line 426 "pdcpars.y"
                        {
				(yyval.twonum).num1=(yyvsp[-2].num);	(yyval.twonum).num2=(yyvsp[0].num);
			}
#line 2308 "pdcpars.tab.c"
    break;

  case 40: /* autolines: commaSYM intnumSYM  */
#line 430 "pdcpars.y"
                        {
				(yyval.twonum).num1=prog_highest_line()+(yyvsp[0].num);	
				(yyval.twonum).num2=(yyvsp[0].num);
			}
#line 2317 "pdcpars.tab.c"
    break;

  case 41: /* autolines: %empty  */
#line 435 "pdcpars.y"
                        {
				(yyval.twonum).num1=prog_highest_line()+10;	
				(yyval.twonum).num2=10;
			}
#line 2326 "pdcpars.tab.c"
    break;

  case 44: /* program_line: %empty  */
#line 444 "pdcpars.y"
                        {
				(yyval.cl).cmd=0;
			}
#line 2334 "pdcpars.tab.c"
    break;

  case 86: /* simple_stat: xid  */
#line 493 "pdcpars.y"
                        {
				(yyval.cl).cmd=execSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 2343 "pdcpars.tab.c"
    break;

  case 89: /* complex_1word: elseSYM  */
#line 502 "pdcpars.y"
                        {
				(yyval.cl).cmd=elseSYM;
			}
#line 2351 "pdcpars.tab.c"
    break;

  case 90: /* complex_1word: endcaseSYM  */
#line 506 "pdcpars.y"
                        {
				(yyval.cl).cmd=endcaseSYM;
			}
#line 2359 "pdcpars.tab.c"
    break;

  case 91: /* complex_1word: endfuncSYM optid  */
#line 510 "pdcpars.y"
                        {
				(yyval.cl).cmd=endfuncSYM;
			}
#line 2367 "pdcpars.tab.c"
    break;

  case 92: /* complex_1word: endifSYM  */
#line 514 "pdcpars.y"
                        {
				(yyval.cl).cmd=endifSYM;
			}
#line 2375 "pdcpars.tab.c"
    break;

  case 93: /* complex_1word: loopSYM  */
#line 518 "pdcpars.y"
                        {
				(yyval.cl).cmd=loopSYM;
			}
#line 2383 "pdcpars.tab.c"
    break;

  case 94: /* complex_1word: endloopSYM  */
#line 522 "pdcpars.y"
                        {
				(yyval.cl).cmd=endloopSYM;
			}
#line 2391 "pdcpars.tab.c"
    break;

  case 95: /* complex_1word: endprocSYM optid2  */
#line 526 "pdcpars.y"
                        {
				(yyval.cl).cmd=endprocSYM;
			}
#line 2399 "pdcpars.tab.c"
    break;

  case 96: /* complex_1word: endwhileSYM  */
#line 530 "pdcpars.y"
                        {
				(yyval.cl).cmd=endwhileSYM;
			}
#line 2407 "pdcpars.tab.c"
    break;

  case 97: /* complex_1word: endforSYM optnumlvalue  */
#line 534 "pdcpars.y"
                        {
				(yyval.cl).cmd=endforSYM;
			}
#line 2415 "pdcpars.tab.c"
    break;

  case 98: /* complex_1word: otherwiseSYM  */
#line 538 "pdcpars.y"
                        {
				(yyval.cl).cmd=otherwiseSYM;
			}
#line 2423 "pdcpars.tab.c"
    break;

  case 99: /* complex_1word: repeatSYM  */
#line 542 "pdcpars.y"
                        {
				(yyval.cl).cmd=repeatSYM;
				(yyval.cl).lc.ifwhilerec.exp=NULL;
				(yyval.cl).lc.ifwhilerec.stat=NULL;
			}
#line 2433 "pdcpars.tab.c"
    break;

  case 100: /* complex_1word: trapSYM  */
#line 548 "pdcpars.y"
                        {
				(yyval.cl).cmd=trapSYM;
				(yyval.cl).lc.traprec.esc=0;
			}
#line 2442 "pdcpars.tab.c"
    break;

  case 101: /* complex_1word: handlerSYM  */
#line 553 "pdcpars.y"
                        {
				(yyval.cl).cmd=handlerSYM;
			}
#line 2450 "pdcpars.tab.c"
    break;

  case 102: /* complex_1word: endtrapSYM  */
#line 557 "pdcpars.y"
                        {
				(yyval.cl).cmd=endtrapSYM;
			}
#line 2458 "pdcpars.tab.c"
    break;

  case 103: /* simple_1word: nullSYM  */
#line 563 "pdcpars.y"
                        {
				(yyval.cl).cmd=nullSYM;
			}
#line 2466 "pdcpars.tab.c"
    break;

  case 104: /* simple_1word: endSYM  */
#line 567 "pdcpars.y"
                        {
				(yyval.cl).cmd=endSYM;
			}
#line 2474 "pdcpars.tab.c"
    break;

  case 105: /* simple_1word: exitSYM  */
#line 571 "pdcpars.y"
                        {
				(yyval.cl).cmd=exitSYM;
				(yyval.cl).lc.exp=NULL;
			}
#line 2483 "pdcpars.tab.c"
    break;

  case 106: /* simple_1word: pageSYM  */
#line 576 "pdcpars.y"
                        {
				(yyval.cl).cmd=pageSYM;
			}
#line 2491 "pdcpars.tab.c"
    break;

  case 107: /* simple_1word: retrySYM  */
#line 580 "pdcpars.y"
                        {
				(yyval.cl).cmd=retrySYM;
			}
#line 2499 "pdcpars.tab.c"
    break;

  case 108: /* case_stat: caseSYM exp optof  */
#line 586 "pdcpars.y"
                        {
				(yyval.cl).cmd=caseSYM;
				(yyval.cl).lc.exp=(yyvsp[-1].exp);
			}
#line 2508 "pdcpars.tab.c"
    break;

  case 109: /* close_stat: closeSYM  */
#line 593 "pdcpars.y"
                        {
				(yyval.cl).cmd=closeSYM;
				(yyval.cl).lc.exproot=NULL;
			}
#line 2517 "pdcpars.tab.c"
    break;

  case 110: /* close_stat: closeSYM optfileS exp_list  */
#line 598 "pdcpars.y"
                        {
				(yyval.cl).cmd=closeSYM;
				(yyval.cl).lc.exproot=my_reverse((yyvsp[0].expptr));
			}
#line 2526 "pdcpars.tab.c"
    break;

  case 111: /* cursor_stat: cursorSYM numexp commaSYM numexp  */
#line 605 "pdcpars.y"
                        {
				(yyval.cl).cmd=cursorSYM;
				(yyval.cl).lc.twoexp.exp1=(yyvsp[-2].exp);
				(yyval.cl).lc.twoexp.exp2=(yyvsp[0].exp);
			}
#line 2536 "pdcpars.tab.c"
    break;

  case 112: /* chdir_stat: chdirSYM stringexp  */
#line 613 "pdcpars.y"
                        {
				(yyval.cl).cmd=chdirSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 2545 "pdcpars.tab.c"
    break;

  case 113: /* rmdir_stat: rmdirSYM stringexp  */
#line 620 "pdcpars.y"
                        {
				(yyval.cl).cmd=rmdirSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 2554 "pdcpars.tab.c"
    break;

  case 114: /* mkdir_stat: mkdirSYM stringexp  */
#line 627 "pdcpars.y"
                        {
				(yyval.cl).cmd=mkdirSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 2563 "pdcpars.tab.c"
    break;

  case 115: /* data_stat: dataSYM exp_list  */
#line 634 "pdcpars.y"
                        {
				(yyval.cl).cmd=dataSYM;
				(yyval.cl).lc.exproot=my_reverse((yyvsp[0].expptr));
			}
#line 2572 "pdcpars.tab.c"
    break;

  case 116: /* del_stat: delSYM stringexp  */
#line 641 "pdcpars.y"
                        {
				(yyval.cl).cmd=delSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 2581 "pdcpars.tab.c"
    break;

  case 117: /* dir_stat: dirSYM opt_stringexp  */
#line 648 "pdcpars.y"
                        {
				(yyval.cl).cmd=dirSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 2590 "pdcpars.tab.c"
    break;

  case 118: /* unit_stat: unitSYM stringexp  */
#line 655 "pdcpars.y"
                        {
				(yyval.cl).cmd=unitSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 2599 "pdcpars.tab.c"
    break;

  case 119: /* local_stat: localSYM local_list  */
#line 663 "pdcpars.y"
                        {
				(yyval.cl).cmd=localSYM;
				(yyval.cl).lc.dimroot=my_reverse((yyvsp[0].dimptr));
			}
#line 2608 "pdcpars.tab.c"
    break;

  case 120: /* local_list: local_list commaSYM local_item  */
#line 669 "pdcpars.y"
                        {
				(yyval.dimptr)=(yyvsp[0].dimptr);
				(yyval.dimptr)->next=(yyvsp[-2].dimptr);
			}
#line 2617 "pdcpars.tab.c"
    break;

  case 121: /* local_list: local_item  */
#line 674 "pdcpars.y"
                        {
				(yyval.dimptr)=(yyvsp[0].dimptr);
				(yyval.dimptr)->next=NULL;
			}
#line 2626 "pdcpars.tab.c"
    break;

  case 122: /* local_item: numid opt_dim_ensions  */
#line 681 "pdcpars.y"
                        {
				(yyval.dimptr)=pars_dimlist_item((yyvsp[-1].id),NULL,(yyvsp[0].dimensionptr));
			}
#line 2634 "pdcpars.tab.c"
    break;

  case 123: /* local_item: stringidSYM  */
#line 685 "pdcpars.y"
                        {
				(yyval.dimptr)=pars_dimlist_item((yyvsp[0].id),NULL,NULL);
			}
#line 2642 "pdcpars.tab.c"
    break;

  case 124: /* local_item: stringidSYM ofSYM numexp  */
#line 689 "pdcpars.y"
                        {
				(yyval.dimptr)=pars_dimlist_item((yyvsp[-2].id),(yyvsp[0].exp),NULL);
			}
#line 2650 "pdcpars.tab.c"
    break;

  case 125: /* local_item: stringidSYM dim_ensions of numexp  */
#line 693 "pdcpars.y"
                        {
				(yyval.dimptr)=pars_dimlist_item((yyvsp[-3].id),(yyvsp[0].exp),(yyvsp[-2].dimensionptr));
			}
#line 2658 "pdcpars.tab.c"
    break;

  case 126: /* local_item: stringidSYM dim_ensions  */
#line 697 "pdcpars.y"
                        {
				(yyval.dimptr)=pars_dimlist_item((yyvsp[-1].id),NULL,(yyvsp[0].dimensionptr));
			}
#line 2666 "pdcpars.tab.c"
    break;

  case 127: /* dim_stat: dimSYM dim_list  */
#line 704 "pdcpars.y"
                        {
				(yyval.cl).cmd=dimSYM;
				(yyval.cl).lc.dimroot=my_reverse((yyvsp[0].dimptr));
			}
#line 2675 "pdcpars.tab.c"
    break;

  case 128: /* dim_list: dim_list commaSYM dim_item  */
#line 711 "pdcpars.y"
                        {
				(yyval.dimptr)=(yyvsp[0].dimptr);
				(yyval.dimptr)->next=(yyvsp[-2].dimptr);
			}
#line 2684 "pdcpars.tab.c"
    break;

  case 129: /* dim_list: dim_item  */
#line 716 "pdcpars.y"
                        {
				(yyval.dimptr)=(yyvsp[0].dimptr);
				(yyval.dimptr)->next=NULL;
			}
#line 2693 "pdcpars.tab.c"
    break;

  case 130: /* dim_item: numid dim_ensions  */
#line 723 "pdcpars.y"
                        {
				(yyval.dimptr)=pars_dimlist_item((yyvsp[-1].id),NULL,(yyvsp[0].dimensionptr));
			}
#line 2701 "pdcpars.tab.c"
    break;

  case 131: /* dim_item: stringidSYM ofSYM numexp  */
#line 727 "pdcpars.y"
                        {
				(yyval.dimptr)=pars_dimlist_item((yyvsp[-2].id),(yyvsp[0].exp),NULL);
			}
#line 2709 "pdcpars.tab.c"
    break;

  case 132: /* dim_item: stringidSYM dim_ensions of numexp  */
#line 731 "pdcpars.y"
                        {
				(yyval.dimptr)=pars_dimlist_item((yyvsp[-3].id),(yyvsp[0].exp),(yyvsp[-2].dimensionptr));
			}
#line 2717 "pdcpars.tab.c"
    break;

  case 133: /* dim_item: stringidSYM dim_ensions  */
#line 735 "pdcpars.y"
                        {
				(yyval.dimptr)=pars_dimlist_item((yyvsp[-1].id),NULL,(yyvsp[0].dimensionptr));
			}
#line 2725 "pdcpars.tab.c"
    break;

  case 137: /* opt_dim_ensions: %empty  */
#line 746 "pdcpars.y"
                        {
				(yyval.dimensionptr)=NULL;
			}
#line 2733 "pdcpars.tab.c"
    break;

  case 138: /* dim_ensions: lparenSYM dim_ension_list rparenSYM  */
#line 752 "pdcpars.y"
                        {
				(yyval.dimensionptr)=(yyvsp[-1].dimensionptr);
			}
#line 2741 "pdcpars.tab.c"
    break;

  case 139: /* dim_ension_list: dim_ension_list commaSYM dim_ension  */
#line 758 "pdcpars.y"
                        {
				(yyval.dimensionptr)=(yyvsp[0].dimensionptr);
				(yyval.dimensionptr)->next=(yyvsp[-2].dimensionptr);
			}
#line 2750 "pdcpars.tab.c"
    break;

  case 140: /* dim_ension_list: dim_ension  */
#line 763 "pdcpars.y"
                        {
				(yyval.dimensionptr)=(yyvsp[0].dimensionptr);
				(yyval.dimensionptr)->next=NULL;
			}
#line 2759 "pdcpars.tab.c"
    break;

  case 141: /* dim_ension: numexp  */
#line 770 "pdcpars.y"
                        {
				(yyval.dimensionptr)=mem_alloc(PARSE_POOL,sizeof(struct dim_ension));
				(yyval.dimensionptr)->bottom=NULL;
				(yyval.dimensionptr)->top=(yyvsp[0].exp);
			}
#line 2769 "pdcpars.tab.c"
    break;

  case 142: /* dim_ension: numexp colonSYM numexp  */
#line 776 "pdcpars.y"
                        {
				(yyval.dimensionptr)=mem_alloc(PARSE_POOL,sizeof(struct dim_ension));
				(yyval.dimensionptr)->bottom=(yyvsp[-2].exp);
				(yyval.dimensionptr)->top=(yyvsp[0].exp);
			}
#line 2779 "pdcpars.tab.c"
    break;

  case 143: /* dim_ension: numexp becminusSYM numexp  */
#line 782 "pdcpars.y"
                        {
				(yyval.dimensionptr)=mem_alloc(PARSE_POOL,sizeof(struct dim_ension));
				(yyval.dimensionptr)->bottom=(yyvsp[-2].exp);
				(yyval.dimensionptr)->top=pars_exp_unary(minusSYM,(yyvsp[0].exp));
			}
#line 2789 "pdcpars.tab.c"
    break;

  case 144: /* elif_stat: elifSYM numexp optthen  */
#line 790 "pdcpars.y"
                        {
				(yyval.cl).cmd=elifSYM;
				(yyval.cl).lc.exp=(yyvsp[-1].exp);
			}
#line 2798 "pdcpars.tab.c"
    break;

  case 145: /* exit_stat: exitSYM ifwhen numexp  */
#line 797 "pdcpars.y"
                        {
				(yyval.cl).cmd=exitSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 2807 "pdcpars.tab.c"
    break;

  case 148: /* exec_stat: execSYM xid  */
#line 808 "pdcpars.y"
                        {
				(yyval.cl).cmd=execSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 2816 "pdcpars.tab.c"
    break;

  case 149: /* for_stat: forSYM numlvalue assign1 numexp todownto numexp optstep optdo optsimple_stat  */
#line 815 "pdcpars.y"
                        {
				(yyval.cl).cmd=forSYM;
				(yyval.cl).lc.forrec.lval=(yyvsp[-7].exp);
				(yyval.cl).lc.forrec.from=(yyvsp[-5].exp);
				(yyval.cl).lc.forrec.mode=(yyvsp[-4].inum);
				(yyval.cl).lc.forrec.to=(yyvsp[-3].exp);
				(yyval.cl).lc.forrec.step=(yyvsp[-2].exp);
				(yyval.cl).lc.forrec.stat=(yyvsp[0].pcl);
			}
#line 2830 "pdcpars.tab.c"
    break;

  case 150: /* todownto: toSYM  */
#line 827 "pdcpars.y"
                        {
				(yyval.inum)=toSYM;
			}
#line 2838 "pdcpars.tab.c"
    break;

  case 151: /* todownto: downtoSYM  */
#line 831 "pdcpars.y"
                        {
				(yyval.inum)=downtoSYM;
			}
#line 2846 "pdcpars.tab.c"
    break;

  case 152: /* optstep: stepSYM numexp  */
#line 837 "pdcpars.y"
                        {
				(yyval.exp)=(yyvsp[0].exp);
			}
#line 2854 "pdcpars.tab.c"
    break;

  case 153: /* optstep: %empty  */
#line 841 "pdcpars.y"
                        {
				(yyval.exp)=NULL;
			}
#line 2862 "pdcpars.tab.c"
    break;

  case 154: /* func_stat: funcSYM id procfunc_head optclosed opt_external  */
#line 847 "pdcpars.y"
                        {
				(yyval.cl).cmd=funcSYM;
				(yyval.cl).lc.pfrec.id=(yyvsp[-3].id);
				(yyval.cl).lc.pfrec.parmroot=my_reverse((yyvsp[-2].parmptr));
				(yyval.cl).lc.pfrec.closed=(yyvsp[-1].inum);
				(yyval.cl).lc.pfrec.external=(yyvsp[0].extptr);
			}
#line 2874 "pdcpars.tab.c"
    break;

  case 155: /* if_stat: ifSYM numexp optthen optsimple_stat  */
#line 857 "pdcpars.y"
                        {
				(yyval.cl).cmd=ifSYM;
				(yyval.cl).lc.ifwhilerec.exp=(yyvsp[-2].exp);
				(yyval.cl).lc.ifwhilerec.stat=(yyvsp[0].pcl);
			}
#line 2884 "pdcpars.tab.c"
    break;

  case 156: /* import_stat: importSYM id colonSYM import_list  */
#line 865 "pdcpars.y"
                        {
				(yyval.cl).cmd=importSYM;
				(yyval.cl).lc.importrec.id=(yyvsp[-2].id);
				(yyval.cl).lc.importrec.importroot=my_reverse((yyvsp[0].importptr));
			}
#line 2894 "pdcpars.tab.c"
    break;

  case 157: /* import_stat: importSYM import_list  */
#line 871 "pdcpars.y"
                        {
				(yyval.cl).cmd=importSYM;
				(yyval.cl).lc.importrec.id=NULL;
				(yyval.cl).lc.importrec.importroot=my_reverse((yyvsp[0].importptr));
			}
#line 2904 "pdcpars.tab.c"
    break;

  case 158: /* import_list: import_list commaSYM oneparm  */
#line 879 "pdcpars.y"
                        {
				(yyval.importptr)=mem_alloc(PARSE_POOL,sizeof(struct import_list));
				(yyval.importptr)->id=(yyvsp[0].oneparm).id;
				(yyval.importptr)->array=(yyvsp[0].oneparm).array;
				(yyval.importptr)->next=(yyvsp[-2].importptr);				
			}
#line 2915 "pdcpars.tab.c"
    break;

  case 159: /* import_list: oneparm  */
#line 886 "pdcpars.y"
                        {
				(yyval.importptr)=mem_alloc(PARSE_POOL,sizeof(struct import_list));
				(yyval.importptr)->id=(yyvsp[0].oneparm).id;
				(yyval.importptr)->array=(yyvsp[0].oneparm).array;
				(yyval.importptr)->next=NULL;
			}
#line 2926 "pdcpars.tab.c"
    break;

  case 160: /* input_stat: inputSYM input_modifier lval_list  */
#line 895 "pdcpars.y"
                        {
				(yyval.cl).cmd=inputSYM;
				(yyval.cl).lc.inputrec.modifier=(yyvsp[-1].imod);
				(yyval.cl).lc.inputrec.lvalroot=my_reverse((yyvsp[0].expptr));
			}
#line 2936 "pdcpars.tab.c"
    break;

  case 161: /* input_modifier: file_designator  */
#line 903 "pdcpars.y"
                        {
				(yyval.imod)=mem_alloc(PARSE_POOL,sizeof(struct input_modifier));
				(yyval.imod)->type=fileSYM;
				(yyval.imod)->data.twoexp=(yyvsp[0].twoexp);
			}
#line 2946 "pdcpars.tab.c"
    break;

  case 162: /* input_modifier: stringSYM colonSYM  */
#line 909 "pdcpars.y"
                        {
				(yyval.imod)=mem_alloc(PARSE_POOL,sizeof(struct input_modifier));
				(yyval.imod)->type=stringSYM;
				(yyval.imod)->data.str=(yyvsp[-1].str);
			}
#line 2956 "pdcpars.tab.c"
    break;

  case 163: /* input_modifier: %empty  */
#line 915 "pdcpars.y"
                        {
				(yyval.imod)=NULL;
			}
#line 2964 "pdcpars.tab.c"
    break;

  case 164: /* open_stat: openSYM fileSYM numexp commaSYM stringexp commaSYM open_type  */
#line 921 "pdcpars.y"
                        {
				(yyval.cl).cmd=openSYM;
				(yyval.cl).lc.openrec=(yyvsp[0].openrec);
				(yyval.cl).lc.openrec.filenum=(yyvsp[-4].exp);
				(yyval.cl).lc.openrec.filename=(yyvsp[-2].exp);
			}
#line 2975 "pdcpars.tab.c"
    break;

  case 165: /* open_type: readSYM  */
#line 930 "pdcpars.y"
                        {
				(yyval.openrec).type=readSYM;
			}
#line 2983 "pdcpars.tab.c"
    break;

  case 166: /* open_type: writeSYM  */
#line 934 "pdcpars.y"
                        {
				(yyval.openrec).type=writeSYM;
			}
#line 2991 "pdcpars.tab.c"
    break;

  case 167: /* open_type: appendSYM  */
#line 938 "pdcpars.y"
                        {
				(yyval.openrec).type=appendSYM;
			}
#line 2999 "pdcpars.tab.c"
    break;

  case 168: /* open_type: randomSYM numexp optread_only  */
#line 942 "pdcpars.y"
                        {
				(yyval.openrec).type=randomSYM;
				(yyval.openrec).reclen=(yyvsp[-1].exp);
				(yyval.openrec).read_only=(yyvsp[0].inum);
			}
#line 3009 "pdcpars.tab.c"
    break;

  case 169: /* os_stat: osSYM stringexp  */
#line 950 "pdcpars.y"
                        {
				(yyval.cl).cmd=osSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 3018 "pdcpars.tab.c"
    break;

  case 170: /* print_stat: printi  */
#line 957 "pdcpars.y"
                        {
				(yyval.cl).cmd=printSYM;
				(yyval.cl).lc.printrec.modifier=NULL;
				(yyval.cl).lc.printrec.printroot=NULL;
				(yyval.cl).lc.printrec.pr_sep=0;
			}
#line 3029 "pdcpars.tab.c"
    break;

  case 171: /* print_stat: printi print_list optpr_sep  */
#line 964 "pdcpars.y"
                        {
				(yyval.cl).cmd=printSYM;
				(yyval.cl).lc.printrec.modifier=NULL;
				(yyval.cl).lc.printrec.printroot=my_reverse((yyvsp[-1].printptr));
				(yyval.cl).lc.printrec.pr_sep=(yyvsp[0].inum);
			}
#line 3040 "pdcpars.tab.c"
    break;

  case 172: /* print_stat: printi usingSYM stringexp colonSYM prnum_list optpr_sep  */
#line 971 "pdcpars.y"
                        {
				(yyval.cl).cmd=printSYM;
				(yyval.cl).lc.printrec.modifier=mem_alloc(PARSE_POOL,sizeof(struct print_modifier));
				(yyval.cl).lc.printrec.modifier->type=usingSYM;
				(yyval.cl).lc.printrec.modifier->data.str=(yyvsp[-3].exp);
				(yyval.cl).lc.printrec.printroot=my_reverse((yyvsp[-1].printptr));
				(yyval.cl).lc.printrec.pr_sep=(yyvsp[0].inum);
			}
#line 3053 "pdcpars.tab.c"
    break;

  case 173: /* print_stat: printi file_designator print_list  */
#line 980 "pdcpars.y"
                        {
				(yyval.cl).cmd=printSYM;
				(yyval.cl).lc.printrec.modifier=mem_alloc(PARSE_POOL,sizeof(struct print_modifier));
				(yyval.cl).lc.printrec.modifier->type=fileSYM;
				(yyval.cl).lc.printrec.modifier->data.twoexp=(yyvsp[-1].twoexp);
				(yyval.cl).lc.printrec.printroot=my_reverse((yyvsp[0].printptr));
				(yyval.cl).lc.printrec.pr_sep=0;
			}
#line 3066 "pdcpars.tab.c"
    break;

  case 176: /* prnum_list: prnum_list pr_sep numexp  */
#line 995 "pdcpars.y"
                        {
				(yyval.printptr)=pars_printlist_item((yyvsp[-1].inum),(yyvsp[0].exp),(yyvsp[-2].printptr));
			}
#line 3074 "pdcpars.tab.c"
    break;

  case 177: /* prnum_list: numexp  */
#line 999 "pdcpars.y"
                        {
				(yyval.printptr)=pars_printlist_item(0,(yyvsp[0].exp),NULL);
			}
#line 3082 "pdcpars.tab.c"
    break;

  case 178: /* print_list: print_list pr_sep exp  */
#line 1005 "pdcpars.y"
                        {
				(yyval.printptr)=pars_printlist_item((yyvsp[-1].inum),(yyvsp[0].exp),(yyvsp[-2].printptr));
			}
#line 3090 "pdcpars.tab.c"
    break;

  case 179: /* print_list: exp  */
#line 1009 "pdcpars.y"
                        {
				(yyval.printptr)=pars_printlist_item(0,(yyvsp[0].exp),NULL);
			}
#line 3098 "pdcpars.tab.c"
    break;

  case 180: /* pr_sep: commaSYM  */
#line 1015 "pdcpars.y"
                        {
				(yyval.inum)=commaSYM;
			}
#line 3106 "pdcpars.tab.c"
    break;

  case 181: /* pr_sep: semicolonSYM  */
#line 1019 "pdcpars.y"
                        {
				(yyval.inum)=semicolonSYM;
			}
#line 3114 "pdcpars.tab.c"
    break;

  case 183: /* optpr_sep: %empty  */
#line 1026 "pdcpars.y"
                        {
				(yyval.inum)=0;
			}
#line 3122 "pdcpars.tab.c"
    break;

  case 184: /* proc_stat: procSYM idSYM procfunc_head optclosed opt_external  */
#line 1032 "pdcpars.y"
                        {
				(yyval.cl).cmd=procSYM;
				(yyval.cl).lc.pfrec.id=(yyvsp[-3].id);
				(yyval.cl).lc.pfrec.parmroot=my_reverse((yyvsp[-2].parmptr));
				(yyval.cl).lc.pfrec.closed=(yyvsp[-1].inum);
				(yyval.cl).lc.pfrec.external=(yyvsp[0].extptr);
			}
#line 3134 "pdcpars.tab.c"
    break;

  case 185: /* read_stat: readSYM optfile lval_list  */
#line 1042 "pdcpars.y"
                        {
				(yyval.cl).cmd=readSYM;
				(yyval.cl).lc.readrec.modifier=(yyvsp[-1].twoexpp);
				(yyval.cl).lc.readrec.lvalroot=my_reverse((yyvsp[0].expptr));
			}
#line 3144 "pdcpars.tab.c"
    break;

  case 186: /* restore_stat: restoreSYM optid2  */
#line 1050 "pdcpars.y"
                        {
				(yyval.cl).cmd=restoreSYM;
				(yyval.cl).lc.id=(yyvsp[0].id);
			}
#line 3153 "pdcpars.tab.c"
    break;

  case 187: /* return_stat: returnSYM optexp  */
#line 1057 "pdcpars.y"
                        {
				(yyval.cl).cmd=returnSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 3162 "pdcpars.tab.c"
    break;

  case 188: /* run_stat: runSYM stringexp  */
#line 1064 "pdcpars.y"
                        {
				(yyval.cl).cmd=runSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 3171 "pdcpars.tab.c"
    break;

  case 189: /* select_out_stat: select_outputSYM stringexp  */
#line 1071 "pdcpars.y"
                        {
				(yyval.cl).cmd=select_outputSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 3180 "pdcpars.tab.c"
    break;

  case 190: /* select_in_stat: select_inputSYM stringexp  */
#line 1079 "pdcpars.y"
                        {
				(yyval.cl).cmd=select_inputSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 3189 "pdcpars.tab.c"
    break;

  case 191: /* stop_stat: stopSYM optexp  */
#line 1086 "pdcpars.y"
                        {
				(yyval.cl).cmd=stopSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 3198 "pdcpars.tab.c"
    break;

  case 192: /* sys_stat: sysSYM exp_list  */
#line 1093 "pdcpars.y"
                        {
				(yyval.cl).cmd=sysSYM;
				(yyval.cl).lc.exproot=my_reverse((yyvsp[0].expptr));
			}
#line 3207 "pdcpars.tab.c"
    break;

  case 193: /* until_stat: untilSYM numexp  */
#line 1100 "pdcpars.y"
                        {
				(yyval.cl).cmd=untilSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 3216 "pdcpars.tab.c"
    break;

  case 194: /* trace_stat: traceSYM numexp  */
#line 1107 "pdcpars.y"
                        {
				char *cmd=exp_cmd((yyvsp[0].exp));
				
				if (strcmp(cmd,"on")!=0 && strcmp(cmd,"off")!=0)
					pars_error("TRACE \"on\" or \"off\"");
				
				(yyval.cl).cmd=traceSYM;
				(yyval.cl).lc.exp=(yyvsp[0].exp);
			}
#line 3230 "pdcpars.tab.c"
    break;

  case 195: /* trap_stat: trapSYM escSYM plusorminus  */
#line 1119 "pdcpars.y"
                        {
				(yyval.cl).cmd=trapSYM;
				(yyval.cl).lc.traprec.esc=(yyvsp[0].inum);
			}
#line 3239 "pdcpars.tab.c"
    break;

  case 196: /* plusorminus: plusSYM  */
#line 1126 "pdcpars.y"
                        {
				(yyval.inum)=plusSYM;
			}
#line 3247 "pdcpars.tab.c"
    break;

  case 197: /* plusorminus: minusSYM  */
#line 1130 "pdcpars.y"
                        {
				(yyval.inum)=minusSYM;
			}
#line 3255 "pdcpars.tab.c"
    break;

  case 198: /* when_stat: whenSYM when_list  */
#line 1136 "pdcpars.y"
                        {
				(yyval.cl).cmd=whenSYM;
				(yyval.cl).lc.whenroot=my_reverse((yyvsp[0].whenptr));
			}
#line 3264 "pdcpars.tab.c"
    break;

  case 201: /* when_numlist: when_numlist commaSYM when_numitem  */
#line 1147 "pdcpars.y"
                        {
				(yyval.whenptr)=(yyvsp[0].whenptr);
				(yyval.whenptr)->next=(yyvsp[-2].whenptr);
			}
#line 3273 "pdcpars.tab.c"
    break;

  case 203: /* when_numitem: relop numexp  */
#line 1155 "pdcpars.y"
                        {
				(yyval.whenptr)=pars_whenlist_item((yyvsp[-1].inum),(yyvsp[0].exp),NULL);
			}
#line 3281 "pdcpars.tab.c"
    break;

  case 204: /* when_numitem: numexp  */
#line 1159 "pdcpars.y"
                        {
				(yyval.whenptr)=pars_whenlist_item(eqlSYM,(yyvsp[0].exp),NULL);
			}
#line 3289 "pdcpars.tab.c"
    break;

  case 205: /* when_strlist: when_strlist commaSYM when_stritem  */
#line 1165 "pdcpars.y"
                        {
				(yyval.whenptr)=(yyvsp[0].whenptr);
				(yyval.whenptr)->next=(yyvsp[-2].whenptr);
			}
#line 3298 "pdcpars.tab.c"
    break;

  case 207: /* when_stritem: relop stringexp  */
#line 1173 "pdcpars.y"
                        {
				(yyval.whenptr)=pars_whenlist_item((yyvsp[-1].inum),(yyvsp[0].exp),NULL);
			}
#line 3306 "pdcpars.tab.c"
    break;

  case 208: /* when_stritem: stringexp  */
#line 1177 "pdcpars.y"
                        {
				(yyval.whenptr)=pars_whenlist_item(eqlSYM,(yyvsp[0].exp),NULL);
			}
#line 3314 "pdcpars.tab.c"
    break;

  case 209: /* when_stritem: inSYM stringexp  */
#line 1181 "pdcpars.y"
                        {
				(yyval.whenptr)=pars_whenlist_item(inSYM,(yyvsp[0].exp),NULL);
			}
#line 3322 "pdcpars.tab.c"
    break;

  case 210: /* relop: gtrSYM  */
#line 1187 "pdcpars.y"
                        {
				(yyval.inum)=gtrSYM;
			}
#line 3330 "pdcpars.tab.c"
    break;

  case 211: /* relop: lssSYM  */
#line 1191 "pdcpars.y"
                        {
				(yyval.inum)=lssSYM;
			}
#line 3338 "pdcpars.tab.c"
    break;

  case 212: /* relop: eqlSYM  */
#line 1195 "pdcpars.y"
                        {
				(yyval.inum)=eqlSYM;
			}
#line 3346 "pdcpars.tab.c"
    break;

  case 213: /* relop: neqSYM  */
#line 1199 "pdcpars.y"
                        {
				(yyval.inum)=neqSYM;
			}
#line 3354 "pdcpars.tab.c"
    break;

  case 214: /* relop: geqSYM  */
#line 1203 "pdcpars.y"
                        {
				(yyval.inum)=geqSYM;
			}
#line 3362 "pdcpars.tab.c"
    break;

  case 215: /* relop: leqSYM  */
#line 1207 "pdcpars.y"
                        {
				(yyval.inum)=leqSYM;
			}
#line 3370 "pdcpars.tab.c"
    break;

  case 216: /* while_stat: whileSYM numexp optdo optsimple_stat  */
#line 1213 "pdcpars.y"
                        {
				(yyval.cl).cmd=whileSYM;
				(yyval.cl).lc.ifwhilerec.exp=(yyvsp[-2].exp);
				(yyval.cl).lc.ifwhilerec.stat=(yyvsp[0].pcl);
			}
#line 3380 "pdcpars.tab.c"
    break;

  case 217: /* repeat_stat: repeatSYM simple_stat untilSYM numexp  */
#line 1221 "pdcpars.y"
                        {
				(yyval.cl).cmd=repeatSYM;
				(yyval.cl).lc.ifwhilerec.exp=(yyvsp[0].exp);
				(yyval.cl).lc.ifwhilerec.stat=stat_dup(&(yyvsp[-2].cl));
			}
#line 3390 "pdcpars.tab.c"
    break;

  case 218: /* write_stat: writeSYM file_designator exp_list  */
#line 1229 "pdcpars.y"
                        {
				(yyval.cl).cmd=writeSYM;
				(yyval.cl).lc.writerec.twoexp=(yyvsp[-1].twoexp);
				(yyval.cl).lc.writerec.exproot=my_reverse((yyvsp[0].expptr));
			}
#line 3400 "pdcpars.tab.c"
    break;

  case 219: /* assign_stat: assign_list  */
#line 1237 "pdcpars.y"
                        {
				(yyval.cl).cmd=becomesSYM;
				(yyval.cl).lc.assignroot=my_reverse((yyvsp[0].assignptr));
			}
#line 3409 "pdcpars.tab.c"
    break;

  case 220: /* assign_list: assign_list semicolonSYM assign_item  */
#line 1244 "pdcpars.y"
                        {
				(yyval.assignptr)=(yyvsp[0].assignptr);
				(yyval.assignptr)->next=(yyvsp[-2].assignptr);
			}
#line 3418 "pdcpars.tab.c"
    break;

  case 221: /* assign_list: assign_item  */
#line 1249 "pdcpars.y"
                        {
				(yyval.assignptr)->next=NULL;
			}
#line 3426 "pdcpars.tab.c"
    break;

  case 222: /* assign_item: numlvalue nassign numexp  */
#line 1255 "pdcpars.y"
                        {
				(yyval.assignptr)=pars_assign_item((yyvsp[-1].inum),(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3434 "pdcpars.tab.c"
    break;

  case 223: /* assign_item: strlvalue sassign stringexp  */
#line 1259 "pdcpars.y"
                        {
				(yyval.assignptr)=pars_assign_item((yyvsp[-1].inum),(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3442 "pdcpars.tab.c"
    break;

  case 227: /* sassign: becplusSYM  */
#line 1270 "pdcpars.y"
                        {
				(yyval.inum)=becplusSYM;
			}
#line 3450 "pdcpars.tab.c"
    break;

  case 228: /* assign1: eqlSYM  */
#line 1276 "pdcpars.y"
                        {
				(yyval.inum)=becomesSYM;
			}
#line 3458 "pdcpars.tab.c"
    break;

  case 229: /* assign1: becomesSYM  */
#line 1280 "pdcpars.y"
                        {
				(yyval.inum)=becomesSYM;
			}
#line 3466 "pdcpars.tab.c"
    break;

  case 230: /* assign2: becplusSYM  */
#line 1286 "pdcpars.y"
                        {
				(yyval.inum)=becplusSYM;
			}
#line 3474 "pdcpars.tab.c"
    break;

  case 231: /* assign2: becminusSYM  */
#line 1290 "pdcpars.y"
                        {
				(yyval.inum)=becminusSYM;
			}
#line 3482 "pdcpars.tab.c"
    break;

  case 232: /* label_stat: idSYM colonSYM  */
#line 1296 "pdcpars.y"
                        {
				(yyval.cl).cmd=idSYM;
				(yyval.cl).lc.id=(yyvsp[-1].id);
			}
#line 3491 "pdcpars.tab.c"
    break;

  case 233: /* xid: idSYM  */
#line 1303 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_id(idSYM,(yyvsp[0].id),NULL);
			}
#line 3499 "pdcpars.tab.c"
    break;

  case 234: /* xid: idSYM lparenSYM exp_list rparenSYM  */
#line 1307 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_id(idSYM,(yyvsp[-3].id),(yyvsp[-1].expptr));
			}
#line 3507 "pdcpars.tab.c"
    break;

  case 235: /* xid: idSYM lparenSYM opt_commalist rparenSYM  */
#line 1311 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_array(idSYM,(yyvsp[-3].id),T_ARRAY);
			}
#line 3515 "pdcpars.tab.c"
    break;

  case 238: /* numexp: numexp2  */
#line 1321 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_num((yyvsp[0].exp));
			}
#line 3523 "pdcpars.tab.c"
    break;

  case 239: /* numexp2: numexp2 eqlSYM numexp2  */
#line 1327 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(eqlSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3531 "pdcpars.tab.c"
    break;

  case 240: /* numexp2: numexp2 neqSYM numexp2  */
#line 1331 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(neqSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3539 "pdcpars.tab.c"
    break;

  case 241: /* numexp2: numexp2 lssSYM numexp2  */
#line 1335 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(lssSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3547 "pdcpars.tab.c"
    break;

  case 242: /* numexp2: numexp2 gtrSYM numexp2  */
#line 1339 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(gtrSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3555 "pdcpars.tab.c"
    break;

  case 243: /* numexp2: numexp2 leqSYM numexp2  */
#line 1343 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(leqSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3563 "pdcpars.tab.c"
    break;

  case 244: /* numexp2: numexp2 geqSYM numexp2  */
#line 1347 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(geqSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3571 "pdcpars.tab.c"
    break;

  case 245: /* numexp2: numexp2 andSYM numexp2  */
#line 1351 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(andSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3579 "pdcpars.tab.c"
    break;

  case 246: /* numexp2: numexp2 andthenSYM numexp2  */
#line 1355 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(andthenSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3587 "pdcpars.tab.c"
    break;

  case 247: /* numexp2: numexp2 orSYM numexp2  */
#line 1359 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(orSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3595 "pdcpars.tab.c"
    break;

  case 248: /* numexp2: numexp2 orthenSYM numexp2  */
#line 1363 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(orthenSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3603 "pdcpars.tab.c"
    break;

  case 249: /* numexp2: numexp2 eorSYM numexp2  */
#line 1367 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(eorSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3611 "pdcpars.tab.c"
    break;

  case 250: /* numexp2: numexp2 plusSYM numexp2  */
#line 1371 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(plusSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3619 "pdcpars.tab.c"
    break;

  case 251: /* numexp2: numexp2 minusSYM numexp2  */
#line 1375 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(minusSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3627 "pdcpars.tab.c"
    break;

  case 252: /* numexp2: numexp2 timesSYM numexp2  */
#line 1379 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(timesSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3635 "pdcpars.tab.c"
    break;

  case 253: /* numexp2: numexp2 divideSYM numexp2  */
#line 1383 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(divideSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3643 "pdcpars.tab.c"
    break;

  case 254: /* numexp2: numexp2 powerSYM numexp2  */
#line 1387 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(powerSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3651 "pdcpars.tab.c"
    break;

  case 255: /* numexp2: numexp2 divSYM numexp2  */
#line 1391 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(divSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3659 "pdcpars.tab.c"
    break;

  case 256: /* numexp2: numexp2 modSYM numexp2  */
#line 1395 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(modSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3667 "pdcpars.tab.c"
    break;

  case 257: /* numexp2: stringexp2 eqlSYM stringexp2  */
#line 1399 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(eqlSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3675 "pdcpars.tab.c"
    break;

  case 258: /* numexp2: stringexp2 neqSYM stringexp2  */
#line 1403 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(neqSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3683 "pdcpars.tab.c"
    break;

  case 259: /* numexp2: stringexp2 lssSYM stringexp2  */
#line 1407 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(lssSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3691 "pdcpars.tab.c"
    break;

  case 260: /* numexp2: stringexp2 gtrSYM stringexp2  */
#line 1411 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(gtrSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3699 "pdcpars.tab.c"
    break;

  case 261: /* numexp2: stringexp2 leqSYM stringexp2  */
#line 1415 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(leqSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3707 "pdcpars.tab.c"
    break;

  case 262: /* numexp2: stringexp2 geqSYM stringexp2  */
#line 1419 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(geqSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3715 "pdcpars.tab.c"
    break;

  case 263: /* numexp2: stringexp2 inSYM stringexp2  */
#line 1423 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(inSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3723 "pdcpars.tab.c"
    break;

  case 264: /* numexp2: minusSYM numexp2  */
#line 1427 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_unary(minusSYM,(yyvsp[0].exp));
			}
#line 3731 "pdcpars.tab.c"
    break;

  case 265: /* numexp2: plusSYM numexp2  */
#line 1431 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_unary(plusSYM,(yyvsp[0].exp));
			}
#line 3739 "pdcpars.tab.c"
    break;

  case 266: /* numexp2: intnumSYM  */
#line 1435 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_int((yyvsp[0].num));
			}
#line 3747 "pdcpars.tab.c"
    break;

  case 267: /* numexp2: floatnumSYM  */
#line 1439 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_float(&(yyvsp[0].dubbel));
			}
#line 3755 "pdcpars.tab.c"
    break;

  case 269: /* numexp2: tsrnSYM lparenSYM stringexp2 rparenSYM  */
#line 1444 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_unary((yyvsp[-3].inum),(yyvsp[-1].exp));
			}
#line 3763 "pdcpars.tab.c"
    break;

  case 270: /* numexp2: tnrnSYM lparenSYM numexp2 rparenSYM  */
#line 1448 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_unary((yyvsp[-3].inum),(yyvsp[-1].exp));
			}
#line 3771 "pdcpars.tab.c"
    break;

  case 271: /* numexp2: rndSYM  */
#line 1452 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(_RND,NULL,NULL);
			}
#line 3779 "pdcpars.tab.c"
    break;

  case 272: /* numexp2: rndSYM lparenSYM numexp2 rparenSYM  */
#line 1456 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(_RND,NULL,(yyvsp[-1].exp));
			}
#line 3787 "pdcpars.tab.c"
    break;

  case 273: /* numexp2: rndSYM lparenSYM numexp2 commaSYM numexp2 rparenSYM  */
#line 1460 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(_RND,(yyvsp[-3].exp),(yyvsp[-1].exp));
			}
#line 3795 "pdcpars.tab.c"
    break;

  case 274: /* numexp2: rnSYM  */
#line 1464 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_const((yyvsp[0].inum));
			}
#line 3803 "pdcpars.tab.c"
    break;

  case 275: /* numexp2: sysSYM lparenSYM exp_list rparenSYM  */
#line 1468 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_sys(sysSYM,T_SYS,(yyvsp[-1].expptr));
			}
#line 3811 "pdcpars.tab.c"
    break;

  case 276: /* numexp2: lparenSYM numexp2 rparenSYM  */
#line 1472 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_unary(lparenSYM,(yyvsp[-1].exp));
			}
#line 3819 "pdcpars.tab.c"
    break;

  case 277: /* stringexp: stringexp2  */
#line 1478 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_str((yyvsp[0].exp));
			}
#line 3827 "pdcpars.tab.c"
    break;

  case 278: /* stringexp2: stringexp2 plusSYM string_factor  */
#line 1484 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(plusSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3835 "pdcpars.tab.c"
    break;

  case 280: /* stringexp2: stringexp2 timesSYM numexp2  */
#line 1489 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_binary(timesSYM,(yyvsp[-2].exp),(yyvsp[0].exp));
			}
#line 3843 "pdcpars.tab.c"
    break;

  case 282: /* opt_stringexp: %empty  */
#line 1496 "pdcpars.y"
                        {
				(yyval.exp)=NULL;
			}
#line 3851 "pdcpars.tab.c"
    break;

  case 284: /* string_factor: string_factor substr_spec  */
#line 1503 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_substr((yyvsp[-1].exp),&(yyvsp[0].twoexp));
			}
#line 3859 "pdcpars.tab.c"
    break;

  case 285: /* string_factor: tnrsSYM lparenSYM numexp2 rparenSYM  */
#line 1507 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_unary((yyvsp[-3].inum),(yyvsp[-1].exp));
			}
#line 3867 "pdcpars.tab.c"
    break;

  case 286: /* string_factor: tsrsSYM lparenSYM stringexp2 rparenSYM  */
#line 1511 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_unary((yyvsp[-3].inum),(yyvsp[-1].exp));
			}
#line 3875 "pdcpars.tab.c"
    break;

  case 287: /* string_factor: rsSYM  */
#line 1515 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_const((yyvsp[0].inum));
			}
#line 3883 "pdcpars.tab.c"
    break;

  case 288: /* string_factor: tonrsSYM opt_arg  */
#line 1519 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_unary((yyvsp[-1].inum),(yyvsp[0].exp));
			}
#line 3891 "pdcpars.tab.c"
    break;

  case 289: /* string_factor: stringSYM  */
#line 1523 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_string((yyvsp[0].str));
			}
#line 3899 "pdcpars.tab.c"
    break;

  case 290: /* string_factor: syssSYM lparenSYM exp_list rparenSYM  */
#line 1527 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_sys(syssSYM,T_SYSS,(yyvsp[-1].expptr));
			}
#line 3907 "pdcpars.tab.c"
    break;

  case 291: /* string_factor: lparenSYM stringexp2 rparenSYM  */
#line 1531 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_unary(lparenSYM,(yyvsp[-1].exp));
			}
#line 3915 "pdcpars.tab.c"
    break;

  case 292: /* opt_arg: lparenSYM numexp2 rparenSYM  */
#line 1537 "pdcpars.y"
                        {
				(yyval.exp)=(yyvsp[-1].exp);
			}
#line 3923 "pdcpars.tab.c"
    break;

  case 293: /* opt_arg: %empty  */
#line 1541 "pdcpars.y"
                        {
				(yyval.exp)=NULL;
			}
#line 3931 "pdcpars.tab.c"
    break;

  case 294: /* substr_spec: lparenSYM substr_spec2 rparenSYM  */
#line 1547 "pdcpars.y"
                        {
				(yyval.twoexp)=(yyvsp[-1].twoexp);
			}
#line 3939 "pdcpars.tab.c"
    break;

  case 295: /* substr_spec2: numexp colonSYM numexp  */
#line 1553 "pdcpars.y"
                        {
				(yyval.twoexp).exp1=(yyvsp[-2].exp);
				(yyval.twoexp).exp2=(yyvsp[0].exp);
			}
#line 3948 "pdcpars.tab.c"
    break;

  case 296: /* substr_spec2: colonSYM numexp  */
#line 1558 "pdcpars.y"
                        {
				(yyval.twoexp).exp1=NULL;
				(yyval.twoexp).exp2=(yyvsp[0].exp);
			}
#line 3957 "pdcpars.tab.c"
    break;

  case 297: /* substr_spec2: numexp colonSYM  */
#line 1563 "pdcpars.y"
                        {
				(yyval.twoexp).exp1=(yyvsp[-1].exp);
				(yyval.twoexp).exp2=NULL;
			}
#line 3966 "pdcpars.tab.c"
    break;

  case 298: /* substr_spec2: colonSYM numexp colonSYM  */
#line 1568 "pdcpars.y"
                        {
				(yyval.twoexp).exp1=(yyvsp[-1].exp);
				(yyval.twoexp).exp2=(yyvsp[-1].exp);
			}
#line 3975 "pdcpars.tab.c"
    break;

  case 300: /* optnumlvalue: %empty  */
#line 1576 "pdcpars.y"
                        {
				(yyval.exp)=NULL;
			}
#line 3983 "pdcpars.tab.c"
    break;

  case 302: /* optexp: %empty  */
#line 1583 "pdcpars.y"
                        {
				(yyval.exp)=NULL;
			}
#line 3991 "pdcpars.tab.c"
    break;

  case 304: /* optid: %empty  */
#line 1590 "pdcpars.y"
                        {
				(yyval.id)=NULL;
			}
#line 3999 "pdcpars.tab.c"
    break;

  case 306: /* optid2: %empty  */
#line 1597 "pdcpars.y"
                        {
				(yyval.id)=NULL;
			}
#line 4007 "pdcpars.tab.c"
    break;

  case 307: /* optfile: file_designator  */
#line 1603 "pdcpars.y"
                        {
				(yyval.twoexpp)=mem_alloc(PARSE_POOL,sizeof(struct two_exp));
				
				*((yyval.twoexpp))=(yyvsp[0].twoexp);
			}
#line 4017 "pdcpars.tab.c"
    break;

  case 308: /* optfile: %empty  */
#line 1609 "pdcpars.y"
                        {	
				(yyval.twoexpp)=NULL;
			}
#line 4025 "pdcpars.tab.c"
    break;

  case 311: /* lval_list: lval_list commaSYM lvalue  */
#line 1619 "pdcpars.y"
                        {
				(yyval.expptr)=pars_explist_item((yyvsp[0].exp),(yyvsp[-2].expptr));
			}
#line 4033 "pdcpars.tab.c"
    break;

  case 312: /* lval_list: lvalue  */
#line 1623 "pdcpars.y"
                        {
				(yyval.expptr)=pars_explist_item((yyvsp[0].exp),NULL);
			}
#line 4041 "pdcpars.tab.c"
    break;

  case 315: /* numlvalue: numlvalue2  */
#line 1633 "pdcpars.y"
                        {
				if (!exp_list_of_nums((yyvsp[0].exp)->e.expid.exproot))
					pars_error("Indices of numeric lvalue \"%s\" must be numerics",(yyvsp[0].exp)->e.expid.id->name);
			}
#line 4050 "pdcpars.tab.c"
    break;

  case 317: /* numlvalue2: intidSYM  */
#line 1641 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_id(intidSYM,(yyvsp[0].id),NULL);
			}
#line 4058 "pdcpars.tab.c"
    break;

  case 318: /* numlvalue2: intidSYM lparenSYM exp_list rparenSYM  */
#line 1645 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_id(intidSYM,(yyvsp[-3].id),(yyvsp[-1].expptr));
			}
#line 4066 "pdcpars.tab.c"
    break;

  case 319: /* numlvalue2: intidSYM lparenSYM opt_commalist rparenSYM  */
#line 1649 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_array(intidSYM,(yyvsp[-3].id),T_ARRAY);
			}
#line 4074 "pdcpars.tab.c"
    break;

  case 320: /* strlvalue: strlvalue2  */
#line 1655 "pdcpars.y"
                        {
				if (!exp_list_of_nums((yyvsp[0].exp)->e.expsid.exproot))
					pars_error("Indices of string lvalue \"%s\" must be numerics",(yyvsp[0].exp)->e.expsid.id->name);
			}
#line 4083 "pdcpars.tab.c"
    break;

  case 321: /* strlvalue2: stringidSYM  */
#line 1662 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_sid((yyvsp[0].id),NULL,NULL);
			}
#line 4091 "pdcpars.tab.c"
    break;

  case 322: /* strlvalue2: stringidSYM lparenSYM exp_list rparenSYM  */
#line 1666 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_sid((yyvsp[-3].id),(yyvsp[-1].expptr),NULL);
			}
#line 4099 "pdcpars.tab.c"
    break;

  case 323: /* strlvalue2: stringidSYM substr_spec  */
#line 1670 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_sid((yyvsp[-1].id),NULL,&(yyvsp[0].twoexp));
			}
#line 4107 "pdcpars.tab.c"
    break;

  case 324: /* strlvalue2: stringidSYM lparenSYM exp_list rparenSYM substr_spec  */
#line 1674 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_sid((yyvsp[-4].id),(yyvsp[-2].expptr),&(yyvsp[0].twoexp));
			}
#line 4115 "pdcpars.tab.c"
    break;

  case 325: /* strlvalue2: stringidSYM lparenSYM opt_commalist rparenSYM  */
#line 1678 "pdcpars.y"
                        {
				(yyval.exp)=pars_exp_array(intidSYM,(yyvsp[-3].id),T_SARRAY);
			}
#line 4123 "pdcpars.tab.c"
    break;

  case 326: /* file_designator: fileSYM numexp colonSYM  */
#line 1684 "pdcpars.y"
                        {
				(yyval.twoexp).exp1=(yyvsp[-1].exp);
				(yyval.twoexp).exp2=NULL;
			}
#line 4132 "pdcpars.tab.c"
    break;

  case 327: /* file_designator: fileSYM numexp commaSYM numexp colonSYM  */
#line 1689 "pdcpars.y"
                        {
				(yyval.twoexp).exp1=(yyvsp[-3].exp);
				(yyval.twoexp).exp2=(yyvsp[-1].exp);
			}
#line 4141 "pdcpars.tab.c"
    break;

  case 328: /* opt_external: externalSYM stringexp  */
#line 1696 "pdcpars.y"
                        {
				(yyval.extptr)=mem_alloc(PARSE_POOL,sizeof(struct ext_rec));
				
				(yyval.extptr)->dynamic=0;
				(yyval.extptr)->filename=(yyvsp[0].exp);
				(yyval.extptr)->seg=NULL;
			}
#line 4153 "pdcpars.tab.c"
    break;

  case 329: /* opt_external: dynamicSYM externalSYM stringexp  */
#line 1704 "pdcpars.y"
                        {
				(yyval.extptr)=mem_alloc(PARSE_POOL,sizeof(struct ext_rec));
				
				(yyval.extptr)->dynamic=dynamicSYM;
				(yyval.extptr)->filename=(yyvsp[0].exp);
				(yyval.extptr)->seg=NULL;
			}
#line 4165 "pdcpars.tab.c"
    break;

  case 330: /* opt_external: staticSYM externalSYM stringexp  */
#line 1712 "pdcpars.y"
                        {
				(yyval.extptr)=mem_alloc(PARSE_POOL,sizeof(struct ext_rec));
				
				(yyval.extptr)->dynamic=staticSYM;
				(yyval.extptr)->filename=(yyvsp[0].exp);
				(yyval.extptr)->seg=NULL;
			}
#line 4177 "pdcpars.tab.c"
    break;

  case 331: /* opt_external: %empty  */
#line 1720 "pdcpars.y"
                        {
				(yyval.extptr)=NULL;
			}
#line 4185 "pdcpars.tab.c"
    break;

  case 332: /* procfunc_head: lparenSYM parmlist rparenSYM  */
#line 1726 "pdcpars.y"
                        {
				(yyval.parmptr)=(yyvsp[-1].parmptr);
			}
#line 4193 "pdcpars.tab.c"
    break;

  case 333: /* procfunc_head: %empty  */
#line 1730 "pdcpars.y"
                        {
				(yyval.parmptr)=NULL;
			}
#line 4201 "pdcpars.tab.c"
    break;

  case 334: /* parmlist: parmlist commaSYM parmitem  */
#line 1736 "pdcpars.y"
                        {
				(yyval.parmptr)=(yyvsp[0].parmptr);
				(yyval.parmptr)->next=(yyvsp[-2].parmptr);
			}
#line 4210 "pdcpars.tab.c"
    break;

  case 335: /* parmlist: parmitem  */
#line 1741 "pdcpars.y"
                        {
				(yyval.parmptr)=(yyvsp[0].parmptr);
				(yyval.parmptr)->next=NULL;
			}
#line 4219 "pdcpars.tab.c"
    break;

  case 336: /* parmitem: oneparm  */
#line 1748 "pdcpars.y"
                        {
				(yyval.parmptr)=mem_alloc(PARSE_POOL,sizeof(struct parm_list));
				(yyval.parmptr)->id=(yyvsp[0].oneparm).id;
				(yyval.parmptr)->array=(yyvsp[0].oneparm).array;
				(yyval.parmptr)->ref=0;
			}
#line 4230 "pdcpars.tab.c"
    break;

  case 337: /* parmitem: refSYM oneparm  */
#line 1755 "pdcpars.y"
                        {
				(yyval.parmptr)=mem_alloc(PARSE_POOL,sizeof(struct parm_list));
				(yyval.parmptr)->id=(yyvsp[0].oneparm).id;
				(yyval.parmptr)->array=(yyvsp[0].oneparm).array;
				(yyval.parmptr)->ref=refSYM;
			}
#line 4241 "pdcpars.tab.c"
    break;

  case 338: /* parmitem: nameSYM id  */
#line 1762 "pdcpars.y"
                        {
				(yyval.parmptr)=mem_alloc(PARSE_POOL,sizeof(struct parm_list));
				(yyval.parmptr)->id=(yyvsp[0].id);
				(yyval.parmptr)->array=0;
				(yyval.parmptr)->ref=nameSYM;
			}
#line 4252 "pdcpars.tab.c"
    break;

  case 339: /* parmitem: procSYM idSYM  */
#line 1769 "pdcpars.y"
                        {
				(yyval.parmptr)=mem_alloc(PARSE_POOL,sizeof(struct parm_list));
				(yyval.parmptr)->id=(yyvsp[0].id);
				(yyval.parmptr)->array=0;
				(yyval.parmptr)->ref=procSYM;
			}
#line 4263 "pdcpars.tab.c"
    break;

  case 340: /* parmitem: funcSYM id  */
#line 1776 "pdcpars.y"
                        {
				(yyval.parmptr)=mem_alloc(PARSE_POOL,sizeof(struct parm_list));
				(yyval.parmptr)->id=(yyvsp[0].id);
				(yyval.parmptr)->array=0;
				(yyval.parmptr)->ref=funcSYM;
			}
#line 4274 "pdcpars.tab.c"
    break;

  case 341: /* oneparm: id  */
#line 1785 "pdcpars.y"
                        {
				(yyval.oneparm).id=(yyvsp[0].id);
				(yyval.oneparm).array=0;
			}
#line 4283 "pdcpars.tab.c"
    break;

  case 342: /* oneparm: id lparenSYM opt_commalist rparenSYM  */
#line 1790 "pdcpars.y"
                        {
				(yyval.oneparm).id=(yyvsp[-3].id);
				(yyval.oneparm).array=1;
			}
#line 4292 "pdcpars.tab.c"
    break;

  case 349: /* exp_list: exp_list commaSYM exp  */
#line 1809 "pdcpars.y"
                        {
				(yyval.expptr)=pars_explist_item((yyvsp[0].exp),(yyvsp[-2].expptr));
				}
#line 4300 "pdcpars.tab.c"
    break;

  case 350: /* exp_list: exp  */
#line 1813 "pdcpars.y"
                        {
				(yyval.expptr)=pars_explist_item((yyvsp[0].exp),NULL);
			}
#line 4308 "pdcpars.tab.c"
    break;

  case 351: /* optsimple_stat: simple_stat  */
#line 1819 "pdcpars.y"
                        {
				if ((yyvsp[0].cl).cmd<0)
					(yyval.pcl)=NULL;
				else
				{
					(yyval.pcl)=stat_dup(&(yyvsp[0].cl));
					(yyval.pcl)->ld=NULL;
				}
			}
#line 4322 "pdcpars.tab.c"
    break;

  case 352: /* optsimple_stat: %empty  */
#line 1829 "pdcpars.y"
                        {
				(yyval.pcl)=NULL;
			}
#line 4330 "pdcpars.tab.c"
    break;

  case 354: /* optfilename: %empty  */
#line 1836 "pdcpars.y"
                        {
				(yyval.str)=NULL;
			}
#line 4338 "pdcpars.tab.c"
    break;

  case 361: /* optread_only: read_onlySYM  */
#line 1854 "pdcpars.y"
                        {
				(yyval.inum)=read_onlySYM;
			}
#line 4346 "pdcpars.tab.c"
    break;

  case 362: /* optread_only: %empty  */
#line 1858 "pdcpars.y"
                        {
				(yyval.inum)=0;
			}
#line 4354 "pdcpars.tab.c"
    break;

  case 363: /* optclosed: closedSYM  */
#line 1864 "pdcpars.y"
                        {
				(yyval.inum)=closedSYM;
			}
#line 4362 "pdcpars.tab.c"
    break;

  case 364: /* optclosed: %empty  */
#line 1868 "pdcpars.y"
                        {
				(yyval.inum)=0;
			}
#line 4370 "pdcpars.tab.c"
    break;


#line 4374 "pdcpars.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 1873 "pdcpars.y"


PRIVATE void p_error(char *s)
	{
		pars_error(s);
		yyclearin;
	}
	
